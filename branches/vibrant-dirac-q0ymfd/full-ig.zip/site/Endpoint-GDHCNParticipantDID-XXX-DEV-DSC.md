# GDHCNParticipantDID-XXX-DEV-DSC - WHO SMART Trust v1.8.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-XXX-DEV-DSC**

## Endpoint: GDHCNParticipantDID-XXX-DEV-DSC

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: Warrandyte Trustlist (DID v2) - DEV - Document Signing Certificates did:web:tng-cdn.who.int:v2:trustlist:-:XXX:DSC resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XXX/DSC/did.json

**managingOrganization**: [Organization Warrandyte](Organization-GDHCNParticipant-XXX-DEV.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:XXX:DSC



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-XXX-DEV-DSC",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Warrandyte Trustlist (DID v2) - DEV - Document Signing Certificates\ndid:web:tng-cdn.who.int:v2:trustlist:-:XXX:DSC\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XXX/DSC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-XXX-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:XXX:DSC"
}

```
