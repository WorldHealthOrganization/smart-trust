# Receive business rules - WHO SMART Trust v1.8.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Receive business rules**

## Requirements: Receive business rules (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/trust/Requirements/ReceiveBusinessRules | *Version*:1.8.0 |
| Active as of 2026-10-01 | *Computable Name*:Receive Business Rules |

 
Receive business rules from a Trust Network Participant, for distribution within the Trust Network 

* Publisher: Contact Email
  * No publisher has been registered.: No contact email has been registered.
* Publisher: Jurisdiction
  * No publisher has been registered.: 
* Publisher: Statements
  * No publisher has been registered.: 
* Publisher: Derived from
  * No publisher has been registered.: This requirement is not derived from another requriement.
* Publisher: Derivatives
  * No publisher has been registered.: This requirement has the following derivatives:
* Publisher: Participating Actors
  * No publisher has been registered.: 



## Resource Content

```json
{
  "resourceType" : "Requirements",
  "id" : "ReceiveBusinessRules",
  "meta" : {
    "profile" : ["http://smart.who.int/base/StructureDefinition/SGRequirements"]
  },
  "url" : "http://smart.who.int/trust/Requirements/ReceiveBusinessRules",
  "version" : "1.8.0",
  "name" : "Receive Business Rules",
  "title" : "Receive business rules",
  "status" : "active",
  "experimental" : true,
  "date" : "2026-10-01T13:03:17+00:00",
  "publisher" : "WHO",
  "contact" : [{
    "name" : "WHO",
    "telecom" : [{
      "system" : "url",
      "value" : "http://who.int"
    }]
  }],
  "description" : "Receive business rules from a Trust Network Participant, for distribution within the Trust Network",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "http://unstats.un.org/unsd/methods/m49/m49.htm",
      "code" : "001"
    }]
  }],
  "actor" : ["http://smart.who.int/trust/ActorDefinition/TrustNetworkAnchor"]
}

```
