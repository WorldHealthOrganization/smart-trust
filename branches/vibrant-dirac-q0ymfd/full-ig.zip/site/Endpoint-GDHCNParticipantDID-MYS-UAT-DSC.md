# GDHCNParticipantDID-MYS-UAT-DSC - WHO SMART Trust v1.8.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-MYS-UAT-DSC**

## Endpoint: GDHCNParticipantDID-MYS-UAT-DSC

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: Malaysia Trustlist (DID v2) - UAT - Document Signing Certificates did:web:tng-cdn.who.int:v2:trustlist:-:MYS:DSC resolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/MYS/DSC/did.json

**managingOrganization**: [Organization Malaysia](Organization-GDHCNParticipant-MYS-UAT.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:MYS:DSC



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-MYS-UAT-DSC",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Malaysia Trustlist (DID v2) - UAT - Document Signing Certificates\ndid:web:tng-cdn.who.int:v2:trustlist:-:MYS:DSC\nresolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/MYS/DSC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-MYS-UAT"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:MYS:DSC"
}

```
