# GDHCNParticipantDID-SMR-DEV-SCA - WHO SMART Trust v1.8.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-SMR-DEV-SCA**

## Endpoint: GDHCNParticipantDID-SMR-DEV-SCA

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: San Marino Trustlist (DID v2) - DEV - Certificate Signing Authority did:web:tng-cdn.who.int:v2:trustlist:-:SMR:SCA resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/SMR/SCA/did.json

**managingOrganization**: [Organization San Marino](Organization-GDHCNParticipant-SMR-DEV.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:SMR:SCA



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-SMR-DEV-SCA",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "San Marino Trustlist (DID v2) - DEV - Certificate Signing Authority\ndid:web:tng-cdn.who.int:v2:trustlist:-:SMR:SCA\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/SMR/SCA/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-SMR-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:SMR:SCA"
}

```
