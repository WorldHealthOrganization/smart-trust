# GDHCNParticipantDID-XXG-DEV-All - WHO SMART Trust v1.8.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-XXG-DEV-All**

## Endpoint: GDHCNParticipantDID-XXG-DEV-All

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: Geneva Trustlist (DID v2) - DEV - All keys did:web:tng-cdn.who.int:v2:trustlist:-:XXG resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XXG/did.json

**managingOrganization**: [Organization Geneva](Organization-GDHCNParticipant-XXG-DEV.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:XXG



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-XXG-DEV-All",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Geneva Trustlist (DID v2) - DEV - All keys\ndid:web:tng-cdn.who.int:v2:trustlist:-:XXG\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XXG/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-XXG-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:XXG"
}

```
