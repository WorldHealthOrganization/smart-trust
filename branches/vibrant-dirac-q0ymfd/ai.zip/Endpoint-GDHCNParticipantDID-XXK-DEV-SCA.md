# GDHCNParticipantDID-XXK-DEV-SCA - WHO SMART Trust v1.8.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-XXK-DEV-SCA**

## Endpoint: GDHCNParticipantDID-XXK-DEV-SCA

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: Rengo Trustlist (DID v2) - DEV - Certificate Signing Authority did:web:tng-cdn.who.int:v2:trustlist:-:XXK:SCA resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XXK/SCA/did.json

**managingOrganization**: [Organization Rengo](Organization-GDHCNParticipant-XXK-DEV.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:XXK:SCA



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-XXK-DEV-SCA",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Rengo Trustlist (DID v2) - DEV - Certificate Signing Authority\ndid:web:tng-cdn.who.int:v2:trustlist:-:XXK:SCA\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XXK/SCA/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-XXK-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:XXK:SCA"
}

```
