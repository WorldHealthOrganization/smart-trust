# Downloads - WHO SMART Trust v1.3.0

* [**Table of Contents**](toc.md)
* [**Deployment**](deployment.md)
* **Downloads**

## Downloads

### Downloads

 Download the entire implementation guide [here](full-ig.zip) 

* Artifact Definitions: Examples
  * [XML](definitions.xml.zip): [XML](examples.xml.zip)
  * [JSON](definitions.json.zip): [JSON](examples.json.zip)
  * [Turtle](definitions.ttl.zip): [Turtle](examples.ttl.zip)

