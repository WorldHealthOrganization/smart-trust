# Changes - WHO SMART Trust v1.3.0

* [**Table of Contents**](toc.md)
* [**Deployment**](deployment.md)
* **Changes**

## Changes

### Changes

 This provides a list of changes to the SMART Trust IG 

 **2024-01-29 v1.0.0 - First stable release** 

**2024-01-29 v1.0.0 - First stable release**

* First stable release

* First stable release

 **2024-02-01 v1.1.0** 

**2024-02-01 v1.1.0**

* Hcert specifications added

* Hcert specifications added

 **2024-02-21 v1.1.1** 

**2024-02-21 v1.1.1**

* video tutorials added

* video tutorials added

 **2024-03-22 v1.1.2 - release** 

**2024-03-22 v1.1.2 - release**

* HCert Logical Model and specification updated with subclaim details and notes
* Rapid assessment template for proposing new trust domains added
* Content Profiles include details about Trust Domain
* FAQ page added
* Link to country participation dashboard added

* HCert Logical Model and specification updated with subclaim details and notes

* Rapid assessment template for proposing new trust domains added

* Content Profiles include details about Trust Domain

* FAQ page added

* Link to country participation dashboard added

 **2024-10-28 v1.1.4 - release** 

**2024-10-28 v1.1.4 - release**

* HCert Logical Model updated with subclaim for DVC
* Onboarding Checklist updated
* Onboarding process revised to remove Transitive processes
* Latest country participation status updated

* HCert Logical Model updated with subclaim for DVC

* Onboarding Checklist updated

* Onboarding process revised to remove Transitive processes

* Latest country participation status updated

 **2024-12-19 v1.1.5 - release** 

**2024-12-19 v1.1.5 - release**

* Onboarding Checklist updated

* Onboarding Checklist updated

