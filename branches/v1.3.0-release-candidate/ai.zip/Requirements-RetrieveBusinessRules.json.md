# Retrieve business rules - JSON Representation - WHO SMART Trust v1.3.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Retrieve business rules**

## : Retrieve business rules - JSON Representation

| |
| :--- |
| Active as of 2025-10-27 |

[Raw json](Requirements-RetrieveBusinessRules.json) | [Download](Requirements-RetrieveBusinessRules.json)

