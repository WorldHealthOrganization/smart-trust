#  - WHO SMART Trust v1.3.0

## : Receive Business Rules - Change History

History of changes for ReceiveBusinessRules .

