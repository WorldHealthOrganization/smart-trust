# Retrieve PKI material - XML Representation - WHO SMART Trust v1.3.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Retrieve PKI material**

## : Retrieve PKI material - XML Representation

| |
| :--- |
| Active as of 2025-10-27 |

[Raw xml](Requirements-RetrievePKIMaterial.xml) | [Download](Requirements-RetrievePKIMaterial.xml)

