# Trust Network Anchor - JSON Representation - WHO SMART Trust v1.3.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Trust Network Anchor**

## : Trust Network Anchor - JSON Representation

| |
| :--- |
| Active as of 2025-10-27 |

[Raw json](ActorDefinition-TrustNetworkAnchor.json) | [Download](ActorDefinition-TrustNetworkAnchor.json)

