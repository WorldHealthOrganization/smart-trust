# GDHCNParticipantDID-XXH-DEV-SCA - WHO SMART Trust v1.6.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-XXH-DEV-SCA**

## Endpoint: GDHCNParticipantDID-XXH-DEV-SCA

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: DEV Participant XXH Trustlist (DID v2) - DEV - Certificate Signing Authority did:web:tng-cdn.who.int:v2:trustlist:-:XXH:SCA resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XXH/SCA/did.json

**managingOrganization**: [Organization DEV Participant XXH](Organization-GDHCNParticipant-XXH-DEV.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:XXH:SCA



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-XXH-DEV-SCA",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "DEV Participant XXH Trustlist (DID v2) - DEV - Certificate Signing Authority\ndid:web:tng-cdn.who.int:v2:trustlist:-:XXH:SCA\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XXH/SCA/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-XXH-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:XXH:SCA"
}

```
