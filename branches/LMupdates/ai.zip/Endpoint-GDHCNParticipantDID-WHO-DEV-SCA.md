# GDHCNParticipantDID-WHO-DEV-SCA - WHO SMART Trust v1.6.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-WHO-DEV-SCA**

## Endpoint: GDHCNParticipantDID-WHO-DEV-SCA

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: DEV Participant WHO Trustlist (DID v2) - DEV - Certificate Signing Authority did:web:tng-cdn.who.int:v2:trustlist:-:WHO:SCA resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/WHO/SCA/did.json

**managingOrganization**: [Organization DEV Participant WHO](Organization-GDHCNParticipant-WHO-DEV.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:WHO:SCA



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-WHO-DEV-SCA",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "DEV Participant WHO Trustlist (DID v2) - DEV - Certificate Signing Authority\ndid:web:tng-cdn.who.int:v2:trustlist:-:WHO:SCA\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/WHO/SCA/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-WHO-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:WHO:SCA"
}

```
