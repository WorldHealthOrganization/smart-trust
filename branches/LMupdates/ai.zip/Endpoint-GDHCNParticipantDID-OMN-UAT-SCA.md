# GDHCNParticipantDID-OMN-UAT-SCA - WHO SMART Trust v1.6.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-OMN-UAT-SCA**

## Endpoint: GDHCNParticipantDID-OMN-UAT-SCA

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: Oman Trustlist (DID v2) - UAT - Certificate Signing Authority did:web:tng-cdn.who.int:v2:trustlist:-:OMN:SCA resolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/OMN/SCA/did.json

**managingOrganization**: [Organization Oman](Organization-GDHCNParticipant-OMN-UAT.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:OMN:SCA



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-OMN-UAT-SCA",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Oman Trustlist (DID v2) - UAT - Certificate Signing Authority\ndid:web:tng-cdn.who.int:v2:trustlist:-:OMN:SCA\nresolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/OMN/SCA/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-OMN-UAT"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:OMN:SCA"
}

```
