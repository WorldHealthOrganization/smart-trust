# GDHCNParticipantDID-BHS-DEV-DSC - WHO SMART Trust v1.7.5

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-BHS-DEV-DSC**

## Endpoint: GDHCNParticipantDID-BHS-DEV-DSC

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Bahamas Trustlist (DID v2) - DEV - Document Signing Certificates did:web:tng-cdn-dev.who.int:v2:trustlist:-:BHS:DSC resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/BHS/DSC/did.json (): did:web:tng-cdn-dev.who.int:v2:trustlist:-:BHS:DSC

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn-dev.who.int:v2:trustlist:-:BHS:DSC |
| Connection Type: |  |
| Managed By: | [Bahamas (Government)](Organization-GDHCNParticipant-BHS-DEV.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-BHS-DEV-DSC",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Bahamas Trustlist (DID v2) - DEV - Document Signing Certificates\ndid:web:tng-cdn-dev.who.int:v2:trustlist:-:BHS:DSC\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/BHS/DSC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-BHS-DEV"
  },
  "address" : "did:web:tng-cdn-dev.who.int:v2:trustlist:-:BHS:DSC"
}

```
