# GDHCNParticipantDID-MCO-UAT-All - WHO SMART Trust v1.7.5

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-MCO-UAT-All**

## Endpoint: GDHCNParticipantDID-MCO-UAT-All

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Monaco Trustlist (DID v2) - UAT - All keys did:web:tng-cdn-uat.who.int:v2:trustlist:-:MCO resolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/MCO/did.json (): did:web:tng-cdn-uat.who.int:v2:trustlist:-:MCO

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn-uat.who.int:v2:trustlist:-:MCO |
| Connection Type: |  |
| Managed By: | [Monaco (Government)](Organization-GDHCNParticipant-MCO-UAT.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-MCO-UAT-All",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Monaco Trustlist (DID v2) - UAT - All keys\ndid:web:tng-cdn-uat.who.int:v2:trustlist:-:MCO\nresolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/MCO/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-MCO-UAT"
  },
  "address" : "did:web:tng-cdn-uat.who.int:v2:trustlist:-:MCO"
}

```
