# GDHCNParticipantDID-BRB-DEV-All - WHO SMART Trust v1.7.5

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-BRB-DEV-All**

## Endpoint: GDHCNParticipantDID-BRB-DEV-All

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Barbados Trustlist (DID v2) - DEV - All keys did:web:tng-cdn-dev.who.int:v2:trustlist:-:BRB resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/BRB/did.json (): did:web:tng-cdn-dev.who.int:v2:trustlist:-:BRB

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn-dev.who.int:v2:trustlist:-:BRB |
| Connection Type: |  |
| Managed By: | [Barbados (Government)](Organization-GDHCNParticipant-BRB-DEV.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-BRB-DEV-All",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Barbados Trustlist (DID v2) - DEV - All keys\ndid:web:tng-cdn-dev.who.int:v2:trustlist:-:BRB\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/BRB/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-BRB-DEV"
  },
  "address" : "did:web:tng-cdn-dev.who.int:v2:trustlist:-:BRB"
}

```
