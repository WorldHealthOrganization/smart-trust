# GDHCNParticipantDID-SVN-DEV-All - WHO SMART Trust v1.7.5

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-SVN-DEV-All**

## Endpoint: GDHCNParticipantDID-SVN-DEV-All

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Slovenia Trustlist (DID v2) - DEV - All keys did:web:tng-cdn-dev.who.int:v2:trustlist:-:SVN resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/SVN/did.json (): did:web:tng-cdn-dev.who.int:v2:trustlist:-:SVN

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn-dev.who.int:v2:trustlist:-:SVN |
| Connection Type: |  |
| Managed By: | [Slovenia (Government)](Organization-GDHCNParticipant-SVN-DEV.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-SVN-DEV-All",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Slovenia Trustlist (DID v2) - DEV - All keys\ndid:web:tng-cdn-dev.who.int:v2:trustlist:-:SVN\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/SVN/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-SVN-DEV"
  },
  "address" : "did:web:tng-cdn-dev.who.int:v2:trustlist:-:SVN"
}

```
