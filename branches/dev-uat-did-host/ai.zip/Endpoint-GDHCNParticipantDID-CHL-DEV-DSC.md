# GDHCNParticipantDID-CHL-DEV-DSC - WHO SMART Trust v1.7.5

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-CHL-DEV-DSC**

## Endpoint: GDHCNParticipantDID-CHL-DEV-DSC

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Chile Trustlist (DID v2) - DEV - Document Signing Certificates did:web:tng-cdn-dev.who.int:v2:trustlist:-:CHL:DSC resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/CHL/DSC/did.json (): did:web:tng-cdn-dev.who.int:v2:trustlist:-:CHL:DSC

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn-dev.who.int:v2:trustlist:-:CHL:DSC |
| Connection Type: |  |
| Managed By: | [Chile (Government)](Organization-GDHCNParticipant-CHL-DEV.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-CHL-DEV-DSC",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Chile Trustlist (DID v2) - DEV - Document Signing Certificates\ndid:web:tng-cdn-dev.who.int:v2:trustlist:-:CHL:DSC\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/CHL/DSC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-CHL-DEV"
  },
  "address" : "did:web:tng-cdn-dev.who.int:v2:trustlist:-:CHL:DSC"
}

```
