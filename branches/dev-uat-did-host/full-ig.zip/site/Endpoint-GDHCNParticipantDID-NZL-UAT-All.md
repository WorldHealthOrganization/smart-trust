# GDHCNParticipantDID-NZL-UAT-All - WHO SMART Trust v1.7.5

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-NZL-UAT-All**

## Endpoint: GDHCNParticipantDID-NZL-UAT-All

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

New Zealand Trustlist (DID v2) - UAT - All keys did:web:tng-cdn-uat.who.int:v2:trustlist:-:NZL resolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/NZL/did.json (): did:web:tng-cdn-uat.who.int:v2:trustlist:-:NZL

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn-uat.who.int:v2:trustlist:-:NZL |
| Connection Type: |  |
| Managed By: | [New Zealand (Government)](Organization-GDHCNParticipant-NZL-UAT.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-NZL-UAT-All",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "New Zealand Trustlist (DID v2) - UAT - All keys\ndid:web:tng-cdn-uat.who.int:v2:trustlist:-:NZL\nresolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/NZL/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-NZL-UAT"
  },
  "address" : "did:web:tng-cdn-uat.who.int:v2:trustlist:-:NZL"
}

```
