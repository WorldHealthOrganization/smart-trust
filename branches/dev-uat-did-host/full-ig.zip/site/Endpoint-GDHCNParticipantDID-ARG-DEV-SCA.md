# GDHCNParticipantDID-ARG-DEV-SCA - WHO SMART Trust v1.7.5

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-ARG-DEV-SCA**

## Endpoint: GDHCNParticipantDID-ARG-DEV-SCA

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Argentina Trustlist (DID v2) - DEV - Certificate Signing Authority did:web:tng-cdn-dev.who.int:v2:trustlist:-:ARG:SCA resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/ARG/SCA/did.json (): did:web:tng-cdn-dev.who.int:v2:trustlist:-:ARG:SCA

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn-dev.who.int:v2:trustlist:-:ARG:SCA |
| Connection Type: |  |
| Managed By: | [Argentina (Government)](Organization-GDHCNParticipant-ARG-DEV.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-ARG-DEV-SCA",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Argentina Trustlist (DID v2) - DEV - Certificate Signing Authority\ndid:web:tng-cdn-dev.who.int:v2:trustlist:-:ARG:SCA\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/ARG/SCA/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-ARG-DEV"
  },
  "address" : "did:web:tng-cdn-dev.who.int:v2:trustlist:-:ARG:SCA"
}

```
