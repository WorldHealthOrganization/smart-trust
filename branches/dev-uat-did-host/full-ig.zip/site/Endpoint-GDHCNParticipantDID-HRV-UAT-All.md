# GDHCNParticipantDID-HRV-UAT-All - WHO SMART Trust v1.7.5

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-HRV-UAT-All**

## Endpoint: GDHCNParticipantDID-HRV-UAT-All

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Croatia Trustlist (DID v2) - UAT - All keys did:web:tng-cdn-uat.who.int:v2:trustlist:-:HRV resolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/HRV/did.json (): did:web:tng-cdn-uat.who.int:v2:trustlist:-:HRV

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn-uat.who.int:v2:trustlist:-:HRV |
| Connection Type: |  |
| Managed By: | [Croatia (Government)](Organization-GDHCNParticipant-HRV-UAT.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-HRV-UAT-All",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Croatia Trustlist (DID v2) - UAT - All keys\ndid:web:tng-cdn-uat.who.int:v2:trustlist:-:HRV\nresolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/HRV/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-HRV-UAT"
  },
  "address" : "did:web:tng-cdn-uat.who.int:v2:trustlist:-:HRV"
}

```
