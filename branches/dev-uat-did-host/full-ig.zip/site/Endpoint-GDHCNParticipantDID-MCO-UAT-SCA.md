# GDHCNParticipantDID-MCO-UAT-SCA - WHO SMART Trust v1.7.5

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-MCO-UAT-SCA**

## Endpoint: GDHCNParticipantDID-MCO-UAT-SCA

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Monaco Trustlist (DID v2) - UAT - Certificate Signing Authority did:web:tng-cdn-uat.who.int:v2:trustlist:-:MCO:SCA resolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/MCO/SCA/did.json (): did:web:tng-cdn-uat.who.int:v2:trustlist:-:MCO:SCA

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn-uat.who.int:v2:trustlist:-:MCO:SCA |
| Connection Type: |  |
| Managed By: | [Monaco (Government)](Organization-GDHCNParticipant-MCO-UAT.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-MCO-UAT-SCA",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Monaco Trustlist (DID v2) - UAT - Certificate Signing Authority\ndid:web:tng-cdn-uat.who.int:v2:trustlist:-:MCO:SCA\nresolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/MCO/SCA/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-MCO-UAT"
  },
  "address" : "did:web:tng-cdn-uat.who.int:v2:trustlist:-:MCO:SCA"
}

```
