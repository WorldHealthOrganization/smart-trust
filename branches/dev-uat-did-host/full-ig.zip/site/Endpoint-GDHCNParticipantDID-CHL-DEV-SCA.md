# GDHCNParticipantDID-CHL-DEV-SCA - WHO SMART Trust v1.7.5

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-CHL-DEV-SCA**

## Endpoint: GDHCNParticipantDID-CHL-DEV-SCA

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Chile Trustlist (DID v2) - DEV - Certificate Signing Authority did:web:tng-cdn-dev.who.int:v2:trustlist:-:CHL:SCA resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/CHL/SCA/did.json (): did:web:tng-cdn-dev.who.int:v2:trustlist:-:CHL:SCA

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn-dev.who.int:v2:trustlist:-:CHL:SCA |
| Connection Type: |  |
| Managed By: | [Chile (Government)](Organization-GDHCNParticipant-CHL-DEV.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-CHL-DEV-SCA",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Chile Trustlist (DID v2) - DEV - Certificate Signing Authority\ndid:web:tng-cdn-dev.who.int:v2:trustlist:-:CHL:SCA\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/CHL/SCA/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-CHL-DEV"
  },
  "address" : "did:web:tng-cdn-dev.who.int:v2:trustlist:-:CHL:SCA"
}

```
