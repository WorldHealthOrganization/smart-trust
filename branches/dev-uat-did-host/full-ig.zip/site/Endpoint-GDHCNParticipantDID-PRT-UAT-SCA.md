# GDHCNParticipantDID-PRT-UAT-SCA - WHO SMART Trust v1.7.5

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-PRT-UAT-SCA**

## Endpoint: GDHCNParticipantDID-PRT-UAT-SCA

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Portugal Trustlist (DID v2) - UAT - Certificate Signing Authority did:web:tng-cdn-uat.who.int:v2:trustlist:-:PRT:SCA resolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/PRT/SCA/did.json (): did:web:tng-cdn-uat.who.int:v2:trustlist:-:PRT:SCA

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn-uat.who.int:v2:trustlist:-:PRT:SCA |
| Connection Type: |  |
| Managed By: | [Portugal (Government)](Organization-GDHCNParticipant-PRT-UAT.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-PRT-UAT-SCA",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Portugal Trustlist (DID v2) - UAT - Certificate Signing Authority\ndid:web:tng-cdn-uat.who.int:v2:trustlist:-:PRT:SCA\nresolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/PRT/SCA/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-PRT-UAT"
  },
  "address" : "did:web:tng-cdn-uat.who.int:v2:trustlist:-:PRT:SCA"
}

```
