# GDHCNParticipantDID-XXX-DEV-All - WHO SMART Trust v1.7.5

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-XXX-DEV-All**

## Endpoint: GDHCNParticipantDID-XXX-DEV-All

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Warrandyte Trustlist (DID v2) - DEV - All keys did:web:tng-cdn-dev.who.int:v2:trustlist:-:XXX resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XXX/did.json (): did:web:tng-cdn-dev.who.int:v2:trustlist:-:XXX

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn-dev.who.int:v2:trustlist:-:XXX |
| Connection Type: |  |
| Managed By: | [Warrandyte (Government)](Organization-GDHCNParticipant-XXX-DEV.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-XXX-DEV-All",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Warrandyte Trustlist (DID v2) - DEV - All keys\ndid:web:tng-cdn-dev.who.int:v2:trustlist:-:XXX\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XXX/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-XXX-DEV"
  },
  "address" : "did:web:tng-cdn-dev.who.int:v2:trustlist:-:XXX"
}

```
