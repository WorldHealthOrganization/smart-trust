# GDHCNParticipantDID-FIN-UAT-DSC - WHO SMART Trust v1.7.5

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-FIN-UAT-DSC**

## Endpoint: GDHCNParticipantDID-FIN-UAT-DSC

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Finland Trustlist (DID v2) - UAT - Document Signing Certificates did:web:tng-cdn-uat.who.int:v2:trustlist:-:FIN:DSC resolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/FIN/DSC/did.json (): did:web:tng-cdn-uat.who.int:v2:trustlist:-:FIN:DSC

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn-uat.who.int:v2:trustlist:-:FIN:DSC |
| Connection Type: |  |
| Managed By: | [Finland (Government)](Organization-GDHCNParticipant-FIN-UAT.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-FIN-UAT-DSC",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Finland Trustlist (DID v2) - UAT - Document Signing Certificates\ndid:web:tng-cdn-uat.who.int:v2:trustlist:-:FIN:DSC\nresolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/FIN/DSC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-FIN-UAT"
  },
  "address" : "did:web:tng-cdn-uat.who.int:v2:trustlist:-:FIN:DSC"
}

```
