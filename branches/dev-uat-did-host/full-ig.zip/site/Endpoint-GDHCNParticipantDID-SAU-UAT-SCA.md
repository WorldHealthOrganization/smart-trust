# GDHCNParticipantDID-SAU-UAT-SCA - WHO SMART Trust v1.7.5

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-SAU-UAT-SCA**

## Endpoint: GDHCNParticipantDID-SAU-UAT-SCA

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Saudi Arabia Trustlist (DID v2) - UAT - Certificate Signing Authority did:web:tng-cdn-uat.who.int:v2:trustlist:-:SAU:SCA resolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/SAU/SCA/did.json (): did:web:tng-cdn-uat.who.int:v2:trustlist:-:SAU:SCA

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn-uat.who.int:v2:trustlist:-:SAU:SCA |
| Connection Type: |  |
| Managed By: | [Saudi Arabia (Government)](Organization-GDHCNParticipant-SAU-UAT.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-SAU-UAT-SCA",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Saudi Arabia Trustlist (DID v2) - UAT - Certificate Signing Authority\ndid:web:tng-cdn-uat.who.int:v2:trustlist:-:SAU:SCA\nresolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/SAU/SCA/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-SAU-UAT"
  },
  "address" : "did:web:tng-cdn-uat.who.int:v2:trustlist:-:SAU:SCA"
}

```
