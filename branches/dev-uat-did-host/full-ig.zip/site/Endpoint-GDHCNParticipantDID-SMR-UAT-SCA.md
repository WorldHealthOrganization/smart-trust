# GDHCNParticipantDID-SMR-UAT-SCA - WHO SMART Trust v1.7.5

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-SMR-UAT-SCA**

## Endpoint: GDHCNParticipantDID-SMR-UAT-SCA

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

San Marino Trustlist (DID v2) - UAT - Certificate Signing Authority did:web:tng-cdn-uat.who.int:v2:trustlist:-:SMR:SCA resolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/SMR/SCA/did.json (): did:web:tng-cdn-uat.who.int:v2:trustlist:-:SMR:SCA

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn-uat.who.int:v2:trustlist:-:SMR:SCA |
| Connection Type: |  |
| Managed By: | [San Marino (Government)](Organization-GDHCNParticipant-SMR-UAT.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-SMR-UAT-SCA",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "San Marino Trustlist (DID v2) - UAT - Certificate Signing Authority\ndid:web:tng-cdn-uat.who.int:v2:trustlist:-:SMR:SCA\nresolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/SMR/SCA/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-SMR-UAT"
  },
  "address" : "did:web:tng-cdn-uat.who.int:v2:trustlist:-:SMR:SCA"
}

```
