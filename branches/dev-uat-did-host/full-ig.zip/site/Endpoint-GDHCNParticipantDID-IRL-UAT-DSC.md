# GDHCNParticipantDID-IRL-UAT-DSC - WHO SMART Trust v1.7.5

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-IRL-UAT-DSC**

## Endpoint: GDHCNParticipantDID-IRL-UAT-DSC

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Ireland Trustlist (DID v2) - UAT - Document Signing Certificates did:web:tng-cdn-uat.who.int:v2:trustlist:-:IRL:DSC resolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/IRL/DSC/did.json (): did:web:tng-cdn-uat.who.int:v2:trustlist:-:IRL:DSC

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn-uat.who.int:v2:trustlist:-:IRL:DSC |
| Connection Type: |  |
| Managed By: | [Ireland (Government)](Organization-GDHCNParticipant-IRL-UAT.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-IRL-UAT-DSC",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Ireland Trustlist (DID v2) - UAT - Document Signing Certificates\ndid:web:tng-cdn-uat.who.int:v2:trustlist:-:IRL:DSC\nresolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/IRL/DSC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-IRL-UAT"
  },
  "address" : "did:web:tng-cdn-uat.who.int:v2:trustlist:-:IRL:DSC"
}

```
