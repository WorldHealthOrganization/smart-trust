# GDHCNParticipantDID-LTU-UAT-DSC - WHO SMART Trust v1.7.5

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-LTU-UAT-DSC**

## Endpoint: GDHCNParticipantDID-LTU-UAT-DSC

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Lithuania Trustlist (DID v2) - UAT - Document Signing Certificates did:web:tng-cdn-uat.who.int:v2:trustlist:-:LTU:DSC resolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/LTU/DSC/did.json (): did:web:tng-cdn-uat.who.int:v2:trustlist:-:LTU:DSC

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn-uat.who.int:v2:trustlist:-:LTU:DSC |
| Connection Type: |  |
| Managed By: | [Lithuania (Government)](Organization-GDHCNParticipant-LTU-UAT.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-LTU-UAT-DSC",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Lithuania Trustlist (DID v2) - UAT - Document Signing Certificates\ndid:web:tng-cdn-uat.who.int:v2:trustlist:-:LTU:DSC\nresolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/LTU/DSC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-LTU-UAT"
  },
  "address" : "did:web:tng-cdn-uat.who.int:v2:trustlist:-:LTU:DSC"
}

```
