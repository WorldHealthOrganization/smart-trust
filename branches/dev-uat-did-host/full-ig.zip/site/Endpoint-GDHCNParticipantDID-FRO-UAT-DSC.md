# GDHCNParticipantDID-FRO-UAT-DSC - WHO SMART Trust v1.7.5

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-FRO-UAT-DSC**

## Endpoint: GDHCNParticipantDID-FRO-UAT-DSC

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Faroe Islands Trustlist (DID v2) - UAT - Document Signing Certificates did:web:tng-cdn-uat.who.int:v2:trustlist:-:FRO:DSC resolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/FRO/DSC/did.json (): did:web:tng-cdn-uat.who.int:v2:trustlist:-:FRO:DSC

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn-uat.who.int:v2:trustlist:-:FRO:DSC |
| Connection Type: |  |
| Managed By: | [Faroe Islands (Government)](Organization-GDHCNParticipant-FRO-UAT.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-FRO-UAT-DSC",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Faroe Islands Trustlist (DID v2) - UAT - Document Signing Certificates\ndid:web:tng-cdn-uat.who.int:v2:trustlist:-:FRO:DSC\nresolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/FRO/DSC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-FRO-UAT"
  },
  "address" : "did:web:tng-cdn-uat.who.int:v2:trustlist:-:FRO:DSC"
}

```
