# WHO RefMart Jurisidiction List - WHO SMART Trust v1.1.6

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **WHO RefMart Jurisidiction List**

## CodeSystem: WHO RefMart Jurisidiction List (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/refmart/CodeSystems/REF_COUNTRY | *Version*:1.1.6 |
| Draft as of 2025-11-19 | *Computable Name*:RefMartCountryList |

 
CodeSystem for WHO Refmart Country and Jurisidiction List available at https://xmart-api-public.who.int/REFMART/REF_COUNTRY for Production environment 

 This Code system is referenced in the content logical definition of the following value sets: 

* [Participants](ValueSet-Participants.md)
* [Participants-DEV](ValueSet-Participants-DEV.md)
* [Participants-UAT](ValueSet-Participants-UAT.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "RefMartCountryList",
  "url" : "http://smart.who.int/refmart/CodeSystems/REF_COUNTRY",
  "version" : "1.1.6",
  "name" : "RefMartCountryList",
  "title" : "WHO RefMart Jurisidiction List",
  "status" : "draft",
  "experimental" : true,
  "date" : "2025-11-19T10:45:54+00:00",
  "publisher" : "WHO",
  "contact" : [
    {
      "name" : "WHO",
      "telecom" : [
        {
          "system" : "url",
          "value" : "http://who.int"
        }
      ]
    }
  ],
  "description" : "CodeSystem for WHO Refmart Country and Jurisidiction List available at https://xmart-api-public.who.int/REFMART/REF_COUNTRY for Production environment",
  "jurisdiction" : [
    {
      "coding" : [
        {
          "system" : "http://unstats.un.org/unsd/methods/m49/m49.htm",
          "code" : "001"
        }
      ]
    }
  ],
  "caseSensitive" : false,
  "content" : "complete",
  "count" : 249,
  "concept" : [
    {
      "code" : "AFG",
      "display" : "Afghanistan"
    },
    {
      "code" : "ALB",
      "display" : "Albania"
    },
    {
      "code" : "DZA",
      "display" : "Algeria"
    },
    {
      "code" : "ASM",
      "display" : "American Samoa"
    },
    {
      "code" : "AND",
      "display" : "Andorra"
    },
    {
      "code" : "AGO",
      "display" : "Angola"
    },
    {
      "code" : "ATG",
      "display" : "Antigua and Barbuda"
    },
    {
      "code" : "AZE",
      "display" : "Azerbaijan"
    },
    {
      "code" : "ARG",
      "display" : "Argentina"
    },
    {
      "code" : "AUS",
      "display" : "Australia"
    },
    {
      "code" : "AUT",
      "display" : "Austria"
    },
    {
      "code" : "BHS",
      "display" : "Bahamas"
    },
    {
      "code" : "BHR",
      "display" : "Bahrain"
    },
    {
      "code" : "BGD",
      "display" : "Bangladesh"
    },
    {
      "code" : "ARM",
      "display" : "Armenia"
    },
    {
      "code" : "BRB",
      "display" : "Barbados"
    },
    {
      "code" : "BEL",
      "display" : "Belgium"
    },
    {
      "code" : "BMU",
      "display" : "Bermuda"
    },
    {
      "code" : "BTN",
      "display" : "Bhutan"
    },
    {
      "code" : "BOL",
      "display" : "Bolivia (Plurinational State of)"
    },
    {
      "code" : "BIH",
      "display" : "Bosnia and Herzegovina"
    },
    {
      "code" : "BWA",
      "display" : "Botswana"
    },
    {
      "code" : "BVT",
      "display" : "Bouvet Island"
    },
    {
      "code" : "BRA",
      "display" : "Brazil"
    },
    {
      "code" : "BLZ",
      "display" : "Belize"
    },
    {
      "code" : "IOT",
      "display" : "British Indian Ocean Territory"
    },
    {
      "code" : "SLB",
      "display" : "Solomon Islands"
    },
    {
      "code" : "VGB",
      "display" : "British Virgin Islands"
    },
    {
      "code" : "BRN",
      "display" : "Brunei Darussalam"
    },
    {
      "code" : "BGR",
      "display" : "Bulgaria"
    },
    {
      "code" : "MMR",
      "display" : "Myanmar"
    },
    {
      "code" : "BDI",
      "display" : "Burundi"
    },
    {
      "code" : "BLR",
      "display" : "Belarus"
    },
    {
      "code" : "KHM",
      "display" : "Cambodia"
    },
    {
      "code" : "CMR",
      "display" : "Cameroon"
    },
    {
      "code" : "CAN",
      "display" : "Canada"
    },
    {
      "code" : "CPV",
      "display" : "Cabo Verde"
    },
    {
      "code" : "CYM",
      "display" : "Cayman Islands"
    },
    {
      "code" : "CAF",
      "display" : "Central African Republic"
    },
    {
      "code" : "LKA",
      "display" : "Sri Lanka"
    },
    {
      "code" : "TCD",
      "display" : "Chad"
    },
    {
      "code" : "CHL",
      "display" : "Chile"
    },
    {
      "code" : "CHN",
      "display" : "China"
    },
    {
      "code" : "TWN",
      "display" : "Taiwan, China"
    },
    {
      "code" : "CXR",
      "display" : "Christmas Island"
    },
    {
      "code" : "CCK",
      "display" : "Cocos (Keeling) Islands"
    },
    {
      "code" : "COL",
      "display" : "Colombia"
    },
    {
      "code" : "COM",
      "display" : "Comoros"
    },
    {
      "code" : "MYT",
      "display" : "Mayotte"
    },
    {
      "code" : "COG",
      "display" : "Congo"
    },
    {
      "code" : "COD",
      "display" : "Democratic Republic of the Congo"
    },
    {
      "code" : "COK",
      "display" : "Cook Islands"
    },
    {
      "code" : "CRI",
      "display" : "Costa Rica"
    },
    {
      "code" : "HRV",
      "display" : "Croatia"
    },
    {
      "code" : "CUB",
      "display" : "Cuba"
    },
    {
      "code" : "CYP",
      "display" : "Cyprus"
    },
    {
      "code" : "CZE",
      "display" : "Czechia"
    },
    {
      "code" : "BEN",
      "display" : "Benin"
    },
    {
      "code" : "DNK",
      "display" : "Denmark"
    },
    {
      "code" : "DMA",
      "display" : "Dominica"
    },
    {
      "code" : "DOM",
      "display" : "Dominican Republic"
    },
    {
      "code" : "ECU",
      "display" : "Ecuador"
    },
    {
      "code" : "SLV",
      "display" : "El Salvador"
    },
    {
      "code" : "GNQ",
      "display" : "Equatorial Guinea"
    },
    {
      "code" : "ETH",
      "display" : "Ethiopia"
    },
    {
      "code" : "ERI",
      "display" : "Eritrea"
    },
    {
      "code" : "EST",
      "display" : "Estonia"
    },
    {
      "code" : "FRO",
      "display" : "Faroe Islands"
    },
    {
      "code" : "FLK",
      "display" : "Falkland Islands (Malvinas)"
    },
    {
      "code" : "SGS",
      "display" : "South Georgia and the South Sandwich Islands"
    },
    {
      "code" : "FJI",
      "display" : "Fiji"
    },
    {
      "code" : "FIN",
      "display" : "Finland"
    },
    {
      "code" : "ALA",
      "display" : "Åland Islands"
    },
    {
      "code" : "FRA",
      "display" : "France"
    },
    {
      "code" : "GUF",
      "display" : "French Guiana"
    },
    {
      "code" : "PYF",
      "display" : "French Polynesia"
    },
    {
      "code" : "ATF",
      "display" : "French Southern Territories"
    },
    {
      "code" : "DJI",
      "display" : "Djibouti"
    },
    {
      "code" : "GAB",
      "display" : "Gabon"
    },
    {
      "code" : "GEO",
      "display" : "Georgia"
    },
    {
      "code" : "GMB",
      "display" : "Gambia"
    },
    {
      "code" : "PSE",
      "display" : "occupied Palestinian territory, including east Jerusalem"
    },
    {
      "code" : "DEU",
      "display" : "Germany"
    },
    {
      "code" : "GHA",
      "display" : "Ghana"
    },
    {
      "code" : "GIB",
      "display" : "Gibraltar"
    },
    {
      "code" : "KIR",
      "display" : "Kiribati"
    },
    {
      "code" : "GRC",
      "display" : "Greece"
    },
    {
      "code" : "GRL",
      "display" : "Greenland"
    },
    {
      "code" : "GRD",
      "display" : "Grenada"
    },
    {
      "code" : "GLP",
      "display" : "Guadeloupe"
    },
    {
      "code" : "GUM",
      "display" : "Guam"
    },
    {
      "code" : "GTM",
      "display" : "Guatemala"
    },
    {
      "code" : "GIN",
      "display" : "Guinea"
    },
    {
      "code" : "GUY",
      "display" : "Guyana"
    },
    {
      "code" : "HTI",
      "display" : "Haiti"
    },
    {
      "code" : "HMD",
      "display" : "Heard Island and McDonald Islands"
    },
    {
      "code" : "VAT",
      "display" : "Holy See"
    },
    {
      "code" : "HND",
      "display" : "Honduras"
    },
    {
      "code" : "HKG",
      "display" : "China, Hong Kong SAR"
    },
    {
      "code" : "HUN",
      "display" : "Hungary"
    },
    {
      "code" : "ISL",
      "display" : "Iceland"
    },
    {
      "code" : "IND",
      "display" : "India"
    },
    {
      "code" : "IDN",
      "display" : "Indonesia"
    },
    {
      "code" : "IRN",
      "display" : "Iran (Islamic Republic of)"
    },
    {
      "code" : "IRQ",
      "display" : "Iraq"
    },
    {
      "code" : "IRL",
      "display" : "Ireland"
    },
    {
      "code" : "ISR",
      "display" : "Israel"
    },
    {
      "code" : "ITA",
      "display" : "Italy"
    },
    {
      "code" : "CIV",
      "display" : "Côte d’Ivoire"
    },
    {
      "code" : "JAM",
      "display" : "Jamaica"
    },
    {
      "code" : "JPN",
      "display" : "Japan"
    },
    {
      "code" : "KAZ",
      "display" : "Kazakhstan"
    },
    {
      "code" : "JOR",
      "display" : "Jordan"
    },
    {
      "code" : "KEN",
      "display" : "Kenya"
    },
    {
      "code" : "PRK",
      "display" : "Democratic People's Republic of Korea"
    },
    {
      "code" : "KOR",
      "display" : "Republic of Korea"
    },
    {
      "code" : "XKX",
      "display" : "Kosovo (in accordance with UN Security Council resolution 1244 (1999))"
    },
    {
      "code" : "KWT",
      "display" : "Kuwait"
    },
    {
      "code" : "KGZ",
      "display" : "Kyrgyzstan"
    },
    {
      "code" : "LAO",
      "display" : "Lao People's Democratic Republic"
    },
    {
      "code" : "LBN",
      "display" : "Lebanon"
    },
    {
      "code" : "LSO",
      "display" : "Lesotho"
    },
    {
      "code" : "LVA",
      "display" : "Latvia"
    },
    {
      "code" : "LBR",
      "display" : "Liberia"
    },
    {
      "code" : "LBY",
      "display" : "Libya"
    },
    {
      "code" : "LIE",
      "display" : "Liechtenstein"
    },
    {
      "code" : "LTU",
      "display" : "Lithuania"
    },
    {
      "code" : "LUX",
      "display" : "Luxembourg"
    },
    {
      "code" : "MAC",
      "display" : "China, Macao SAR"
    },
    {
      "code" : "MDG",
      "display" : "Madagascar"
    },
    {
      "code" : "MWI",
      "display" : "Malawi"
    },
    {
      "code" : "MYS",
      "display" : "Malaysia"
    },
    {
      "code" : "MDV",
      "display" : "Maldives"
    },
    {
      "code" : "MLI",
      "display" : "Mali"
    },
    {
      "code" : "MLT",
      "display" : "Malta"
    },
    {
      "code" : "MTQ",
      "display" : "Martinique"
    },
    {
      "code" : "MRT",
      "display" : "Mauritania"
    },
    {
      "code" : "MUS",
      "display" : "Mauritius"
    },
    {
      "code" : "MEX",
      "display" : "Mexico"
    },
    {
      "code" : "MCO",
      "display" : "Monaco"
    },
    {
      "code" : "MNG",
      "display" : "Mongolia"
    },
    {
      "code" : "MDA",
      "display" : "Republic of Moldova"
    },
    {
      "code" : "MNE",
      "display" : "Montenegro"
    },
    {
      "code" : "MSR",
      "display" : "Montserrat"
    },
    {
      "code" : "MAR",
      "display" : "Morocco"
    },
    {
      "code" : "MOZ",
      "display" : "Mozambique"
    },
    {
      "code" : "OMN",
      "display" : "Oman"
    },
    {
      "code" : "NAM",
      "display" : "Namibia"
    },
    {
      "code" : "NRU",
      "display" : "Nauru"
    },
    {
      "code" : "NPL",
      "display" : "Nepal"
    },
    {
      "code" : "NLD",
      "display" : "Netherlands (Kingdom of the)"
    },
    {
      "code" : "CUW",
      "display" : "Curaçao"
    },
    {
      "code" : "ABW",
      "display" : "Aruba"
    },
    {
      "code" : "SXM",
      "display" : "Sint Maarten (Dutch part)"
    },
    {
      "code" : "BES",
      "display" : "Bonaire, Sint Eustatius and Saba"
    },
    {
      "code" : "NCL",
      "display" : "New Caledonia"
    },
    {
      "code" : "VUT",
      "display" : "Vanuatu"
    },
    {
      "code" : "NZL",
      "display" : "New Zealand"
    },
    {
      "code" : "NIC",
      "display" : "Nicaragua"
    },
    {
      "code" : "NER",
      "display" : "Niger"
    },
    {
      "code" : "NGA",
      "display" : "Nigeria"
    },
    {
      "code" : "NIU",
      "display" : "Niue"
    },
    {
      "code" : "NFK",
      "display" : "Norfolk Island"
    },
    {
      "code" : "NOR",
      "display" : "Norway"
    },
    {
      "code" : "MNP",
      "display" : "Northern Mariana Islands"
    },
    {
      "code" : "UMI",
      "display" : "United States Minor Outlying Islands"
    },
    {
      "code" : "FSM",
      "display" : "Micronesia (Federated States of)"
    },
    {
      "code" : "MHL",
      "display" : "Marshall Islands"
    },
    {
      "code" : "PLW",
      "display" : "Palau"
    },
    {
      "code" : "PAK",
      "display" : "Pakistan"
    },
    {
      "code" : "PAN",
      "display" : "Panama"
    },
    {
      "code" : "PNG",
      "display" : "Papua New Guinea"
    },
    {
      "code" : "PRY",
      "display" : "Paraguay"
    },
    {
      "code" : "PER",
      "display" : "Peru"
    },
    {
      "code" : "PHL",
      "display" : "Philippines"
    },
    {
      "code" : "PCN",
      "display" : "Pitcairn"
    },
    {
      "code" : "POL",
      "display" : "Poland"
    },
    {
      "code" : "PRT",
      "display" : "Portugal"
    },
    {
      "code" : "GNB",
      "display" : "Guinea-Bissau"
    },
    {
      "code" : "TLS",
      "display" : "Timor-Leste"
    },
    {
      "code" : "PRI",
      "display" : "Puerto Rico"
    },
    {
      "code" : "QAT",
      "display" : "Qatar"
    },
    {
      "code" : "REU",
      "display" : "Réunion"
    },
    {
      "code" : "ROU",
      "display" : "Romania"
    },
    {
      "code" : "RUS",
      "display" : "Russian Federation"
    },
    {
      "code" : "RWA",
      "display" : "Rwanda"
    },
    {
      "code" : "BLM",
      "display" : "Saint Barthélemy"
    },
    {
      "code" : "SHN",
      "display" : "Saint Helena"
    },
    {
      "code" : "KNA",
      "display" : "Saint Kitts and Nevis"
    },
    {
      "code" : "AIA",
      "display" : "Anguilla"
    },
    {
      "code" : "LCA",
      "display" : "Saint Lucia"
    },
    {
      "code" : "MAF",
      "display" : "Saint Martin (French part)"
    },
    {
      "code" : "SPM",
      "display" : "Saint Pierre and Miquelon"
    },
    {
      "code" : "VCT",
      "display" : "Saint Vincent and the Grenadines"
    },
    {
      "code" : "SMR",
      "display" : "San Marino"
    },
    {
      "code" : "STP",
      "display" : "Sao Tome and Principe"
    },
    {
      "code" : "SAU",
      "display" : "Saudi Arabia"
    },
    {
      "code" : "SEN",
      "display" : "Senegal"
    },
    {
      "code" : "SRB",
      "display" : "Serbia"
    },
    {
      "code" : "SYC",
      "display" : "Seychelles"
    },
    {
      "code" : "SLE",
      "display" : "Sierra Leone"
    },
    {
      "code" : "SGP",
      "display" : "Singapore"
    },
    {
      "code" : "SVK",
      "display" : "Slovakia"
    },
    {
      "code" : "VNM",
      "display" : "Viet Nam"
    },
    {
      "code" : "SVN",
      "display" : "Slovenia"
    },
    {
      "code" : "SOM",
      "display" : "Somalia"
    },
    {
      "code" : "ZAF",
      "display" : "South Africa"
    },
    {
      "code" : "ZWE",
      "display" : "Zimbabwe"
    },
    {
      "code" : "ESP",
      "display" : "Spain"
    },
    {
      "code" : "SSD",
      "display" : "South Sudan"
    },
    {
      "code" : "SDN",
      "display" : "Sudan"
    },
    {
      "code" : "ESH",
      "display" : "Western Sahara"
    },
    {
      "code" : "SUR",
      "display" : "Suriname"
    },
    {
      "code" : "SJM",
      "display" : "Svalbard and Jan Mayen"
    },
    {
      "code" : "SWZ",
      "display" : "Eswatini"
    },
    {
      "code" : "SWE",
      "display" : "Sweden"
    },
    {
      "code" : "CHE",
      "display" : "Switzerland"
    },
    {
      "code" : "SYR",
      "display" : "Syrian Arab Republic"
    },
    {
      "code" : "TJK",
      "display" : "Tajikistan"
    },
    {
      "code" : "THA",
      "display" : "Thailand"
    },
    {
      "code" : "TGO",
      "display" : "Togo"
    },
    {
      "code" : "TKL",
      "display" : "Tokelau"
    },
    {
      "code" : "TON",
      "display" : "Tonga"
    },
    {
      "code" : "TTO",
      "display" : "Trinidad and Tobago"
    },
    {
      "code" : "ARE",
      "display" : "United Arab Emirates"
    },
    {
      "code" : "TUN",
      "display" : "Tunisia"
    },
    {
      "code" : "TUR",
      "display" : "Türkiye"
    },
    {
      "code" : "TKM",
      "display" : "Turkmenistan"
    },
    {
      "code" : "TCA",
      "display" : "Turks and Caicos Islands"
    },
    {
      "code" : "TUV",
      "display" : "Tuvalu"
    },
    {
      "code" : "UGA",
      "display" : "Uganda"
    },
    {
      "code" : "UKR",
      "display" : "Ukraine"
    },
    {
      "code" : "MKD",
      "display" : "North Macedonia"
    },
    {
      "code" : "EGY",
      "display" : "Egypt"
    },
    {
      "code" : "GBR",
      "display" : "United Kingdom of Great Britain and Northern Ireland"
    },
    {
      "code" : "GGY",
      "display" : "Guernsey"
    },
    {
      "code" : "JEY",
      "display" : "Jersey"
    },
    {
      "code" : "IMN",
      "display" : "Isle of Man"
    },
    {
      "code" : "TZA",
      "display" : "United Republic of Tanzania"
    },
    {
      "code" : "USA",
      "display" : "United States of America"
    },
    {
      "code" : "VIR",
      "display" : "United States Virgin Islands"
    },
    {
      "code" : "BFA",
      "display" : "Burkina Faso"
    },
    {
      "code" : "URY",
      "display" : "Uruguay"
    },
    {
      "code" : "UZB",
      "display" : "Uzbekistan"
    },
    {
      "code" : "VEN",
      "display" : "Venezuela (Bolivarian Republic of)"
    },
    {
      "code" : "WLF",
      "display" : "Wallis and Futuna"
    },
    {
      "code" : "WSM",
      "display" : "Samoa"
    },
    {
      "code" : "YEM",
      "display" : "Yemen"
    },
    {
      "code" : "ZMB",
      "display" : "Zambia"
    }
  ]
}

```
