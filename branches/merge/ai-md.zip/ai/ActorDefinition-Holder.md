# Holder - WHO SMART Trust v1.1.6

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Holder**

WHO SMART Trust, published by WHO. This guide is not an authorized publication; it is the continuous build for version 1.1.6 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/WorldHealthOrganization/smart-trust/tree/103/merge](https://github.com/WorldHealthOrganization/smart-trust/tree/103/merge) and changes regularly. See the [Directory of published versions](http://smart.who.int/trust/history.html)

*  [Narrative Content](#) 
*  [XML](ActorDefinition-Holder.xml.md) 
*  [JSON](ActorDefinition-Holder.json.md) 
*  [TTL](ActorDefinition-Holder.ttl.md) 

## ActorDefinition: Holder (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/trust/ActorDefinition/Holder | *Version*:1.1.6 |
| Active as of 2025-10-06 | *Computable Name*:Holder |

 
A Holder is an individual that has Verifiable Digtial Health Certificate in their possesion, received from an Issuer. The Holder may choose to share the Verifiable Digital Health Certificate with a Receiver. 

* Publisher: Contact Email
  * No publisher has been registered.: No contact email has been registered.
* Publisher: Jurisdiction
  * No publisher has been registered.: 
* Publisher: Requirements
  * No publisher has been registered.: This actor fulfills the following requirements:

| | | |
| :--- | :--- | :--- |
|  [<prev](artifacts.md) | [top](#top) |  [next>](ActorDefinition-Holder-testing.md) |

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust#1.1.6 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust/history.html)|[License](license.md) 

