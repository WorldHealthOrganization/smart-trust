#  - WHO SMART Trust v1.1.6

WHO SMART Trust, published by WHO. This guide is not an authorized publication; it is the continuous build for version 1.1.6 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/WorldHealthOrganization/smart-trust/tree/103/merge](https://github.com/WorldHealthOrganization/smart-trust/tree/103/merge) and changes regularly. See the [Directory of published versions](http://smart.who.int/trust/history.html)

*  [Narrative Content](Endpoint-GDHCNParticipantDID-ARM-DSC.md) 
*  [XML](Endpoint-GDHCNParticipantDID-ARM-DSC.xml.md) 
*  [JSON](Endpoint-GDHCNParticipantDID-ARM-DSC.json.md) 
*  [TTL](Endpoint-GDHCNParticipantDID-ARM-DSC.ttl.md) 

## : Armenia Trustlist (DID v2) - Document Signing Certificates did:web:tng-cdn.who.int:v2:trustlist:-:ARM:DSC resolvable at https://tng-cdn.who.int/v2/trustlist/-/ARM/DSC/did.json - Change History

History of changes for GDHCNParticipantDID-ARM-DSC .

| | | |
| :--- | :--- | :--- |
|  <prev | [top](#top) |  next> |

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust#1.1.6 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust/history.html)|[License](license.md) 

