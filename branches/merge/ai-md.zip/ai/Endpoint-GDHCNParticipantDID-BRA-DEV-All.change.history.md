#  - WHO SMART Trust v1.1.6

WHO SMART Trust, published by WHO. This guide is not an authorized publication; it is the continuous build for version 1.1.6 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/WorldHealthOrganization/smart-trust/tree/103/merge](https://github.com/WorldHealthOrganization/smart-trust/tree/103/merge) and changes regularly. See the [Directory of published versions](http://smart.who.int/trust/history.html)

*  [Narrative Content](Endpoint-GDHCNParticipantDID-BRA-DEV-All.md) 
*  [XML](Endpoint-GDHCNParticipantDID-BRA-DEV-All.xml.md) 
*  [JSON](Endpoint-GDHCNParticipantDID-BRA-DEV-All.json.md) 
*  [TTL](Endpoint-GDHCNParticipantDID-BRA-DEV-All.ttl.md) 

## : Brazil Trustlist (DID v2) - DEV - All keys did:web:tng-cdn.who.int:v2:trustlist:-:BRA resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/BRA/did.json - Change History

History of changes for GDHCNParticipantDID-BRA-DEV-All .

| | | |
| :--- | :--- | :--- |
|  <prev | [top](#top) |  next> |

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust#1.1.6 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust/history.html)|[License](license.md) 

