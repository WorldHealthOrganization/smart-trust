# WHO GDHCN Payload Types - WHO SMART Trust v1.1.6

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **WHO GDHCN Payload Types**

WHO SMART Trust, published by WHO. This guide is not an authorized publication; it is the continuous build for version 1.1.6 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/WorldHealthOrganization/smart-trust/tree/103/merge](https://github.com/WorldHealthOrganization/smart-trust/tree/103/merge) and changes regularly. See the [Directory of published versions](http://smart.who.int/trust/history.html)

*  [Narrative Content](#) 
*  [XML](CodeSystem-PayloadTypes.xml.md) 
*  [JSON](CodeSystem-PayloadTypes.json.md) 
*  [TTL](CodeSystem-PayloadTypes.ttl.md) 

## CodeSystem: WHO GDHCN Payload Types (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/trust/CodeSystem/PayloadTypes | *Version*:1.1.6 |
| Active as of 2025-10-06 | *Computable Name*:PayloadTypes |

 
CodeSystem for GDHCN Payload types 

 This Code system is referenced in the content logical definition of the following value sets: 

* [PayloadTypes](ValueSet-PayloadTypes.md)

This case-insensitive code system `http://smart.who.int/trust/CodeSystem/PayloadTypes` defines the following code:

| | | |
| :--- | :--- | :--- |
|  [<prev](CodeSystem-KeyUsage-UAT.ttl.md) | [top](#top) |  [next>](CodeSystem-PayloadTypes-testing.md) |

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust#1.1.6 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust/history.html)|[License](license.md) 

