# GDHCNParticipantDID-DOM-DEV-All - WHO SMART Trust v1.7.5

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-DOM-DEV-All**

## Endpoint: GDHCNParticipantDID-DOM-DEV-All

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Dominican Republic Trustlist (DID v2) - DEV - All keys did:web:tng-cdn.who.int:v2:trustlist:-:DOM resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/DOM/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:DOM

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:DOM |
| Connection Type: |  |
| Managed By: | [Dominican Republic (Government)](Organization-GDHCNParticipant-DOM-DEV.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-DOM-DEV-All",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Dominican Republic Trustlist (DID v2) - DEV - All keys\ndid:web:tng-cdn.who.int:v2:trustlist:-:DOM\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/DOM/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-DOM-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:DOM"
}

```
