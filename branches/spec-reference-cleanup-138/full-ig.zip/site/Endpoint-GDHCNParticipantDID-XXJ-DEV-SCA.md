# GDHCNParticipantDID-XXJ-DEV-SCA - WHO SMART Trust v1.7.5

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-XXJ-DEV-SCA**

## Endpoint: GDHCNParticipantDID-XXJ-DEV-SCA

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

DEV Participant XXJ Trustlist (DID v2) - DEV - Certificate Signing Authority did:web:tng-cdn.who.int:v2:trustlist:-:XXJ:SCA resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XXJ/SCA/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:XXJ:SCA

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:XXJ:SCA |
| Connection Type: |  |
| Managed By: | [DEV Participant XXJ (Government)](Organization-GDHCNParticipant-XXJ-DEV.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-XXJ-DEV-SCA",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "DEV Participant XXJ Trustlist (DID v2) - DEV - Certificate Signing Authority\ndid:web:tng-cdn.who.int:v2:trustlist:-:XXJ:SCA\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XXJ/SCA/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-XXJ-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:XXJ:SCA"
}

```
