# GDHCNParticipantDID-PAN-UAT-SCA - WHO SMART Trust v1.7.5

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-PAN-UAT-SCA**

## Endpoint: GDHCNParticipantDID-PAN-UAT-SCA

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Panama Trustlist (DID v2) - UAT - Certificate Signing Authority did:web:tng-cdn.who.int:v2:trustlist:-:PAN:SCA resolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/PAN/SCA/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:PAN:SCA

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:PAN:SCA |
| Connection Type: |  |
| Managed By: | [Panama (Government)](Organization-GDHCNParticipant-PAN-UAT.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-PAN-UAT-SCA",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Panama Trustlist (DID v2) - UAT - Certificate Signing Authority\ndid:web:tng-cdn.who.int:v2:trustlist:-:PAN:SCA\nresolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/PAN/SCA/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-PAN-UAT"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:PAN:SCA"
}

```
