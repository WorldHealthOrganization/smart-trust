# GDHCNParticipantDID-XYK-DEV-DSC - WHO SMART Trust v1.7.5

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-XYK-DEV-DSC**

## Endpoint: GDHCNParticipantDID-XYK-DEV-DSC

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Test Trustlist (DID v2) - DEV - Document Signing Certificates did:web:tng-cdn.who.int:v2:trustlist:-:XYK:DSC resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XYK/DSC/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:XYK:DSC

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:XYK:DSC |
| Connection Type: |  |
| Managed By: | [Test (Government)](Organization-GDHCNParticipant-XYK-DEV.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-XYK-DEV-DSC",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Test Trustlist (DID v2) - DEV - Document Signing Certificates\ndid:web:tng-cdn.who.int:v2:trustlist:-:XYK:DSC\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XYK/DSC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-XYK-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:XYK:DSC"
}

```
