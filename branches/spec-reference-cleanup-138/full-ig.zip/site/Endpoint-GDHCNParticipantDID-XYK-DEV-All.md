# GDHCNParticipantDID-XYK-DEV-All - WHO SMART Trust v1.7.5

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-XYK-DEV-All**

## Endpoint: GDHCNParticipantDID-XYK-DEV-All

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Test Trustlist (DID v2) - DEV - All keys did:web:tng-cdn.who.int:v2:trustlist:-:XYK resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XYK/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:XYK

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:XYK |
| Connection Type: |  |
| Managed By: | [Test (Government)](Organization-GDHCNParticipant-XYK-DEV.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-XYK-DEV-All",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Test Trustlist (DID v2) - DEV - All keys\ndid:web:tng-cdn.who.int:v2:trustlist:-:XYK\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XYK/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-XYK-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:XYK"
}

```
