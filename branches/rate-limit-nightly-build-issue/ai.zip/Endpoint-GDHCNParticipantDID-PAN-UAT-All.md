# GDHCNParticipantDID-PAN-UAT-All - WHO SMART Trust v1.6.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-PAN-UAT-All**

## Endpoint: GDHCNParticipantDID-PAN-UAT-All

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: Panama Trustlist (DID v2) - UAT - All keys did:web:tng-cdn.who.int:v2:trustlist:-:PAN resolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/PAN/did.json

**managingOrganization**: [Organization Panama](Organization-GDHCNParticipant-PAN-UAT.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:PAN



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-PAN-UAT-All",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Panama Trustlist (DID v2) - UAT - All keys\ndid:web:tng-cdn.who.int:v2:trustlist:-:PAN\nresolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/PAN/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-PAN-UAT"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:PAN"
}

```
