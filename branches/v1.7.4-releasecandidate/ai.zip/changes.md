# Changes - WHO SMART Trust v1.7.4

* [**Table of Contents**](toc.md)
* [**Deployment**](deployment.md)
* **Changes**

## Changes

### Changes

This provides a list of changes to the SMART Trust IG.

### 2024-01-29 v1.0.0 - First stable release

* First stable release

### 2024-02-01 v1.1.0

* Hcert specifications added

### 2024-02-21 v1.1.1

* video tutorials added

### 2024-03-22 v1.1.2 - release

* HCert Logical Model and specification updated with subclaim details and notes
* Rapid assessment template for proposing new trust domains added
* Content Profiles include details about Trust Domain
* FAQ page added
* Link to country participation dashboard added

### 2024-10-28 v1.1.4 - release

* HCert Logical Model updated with subclaim for DVC
* Onboarding Checklist updated
* Onboarding process revised to remove Transitive processes
* Latest country participation status updated

### 2024-12-19 v1.1.5 - release

* Onboarding Checklist updated

### 2025-04-02 v1.2.0 - release

* Upgraded to FHIR 5.0.0
* IPS Pilgrimage trust domain added
* PH4H Letters of Application added (English and Spanish)
* DAK API Documentation Hub added
* TNG Endpoints page added covering DEV, UAT, and PROD environments
* Participant ValueSets for DEV, UAT, and PROD environments introduced with automated nightly generation
* DID Trustlist v2 added (multiple DID files per key type); DID Trustlist v1 deprecated

### 2025-10-27 v1.3.0 - release

* Trust Network Gateway additional context JSON-LD file added
* DID context extension links updated to reference FHIR specifications
* Participant lists updated

### 2026-02-11 v1.4.0 - release

* Onboarding Checklist updated with detailed curl command validation instructions
* Windows-specific curl instructions added (OpenSSL-based build required)
* IOM country mapping added
* Participant lists updated

### 2026-04-27 v1.5.0 - release

* C.L.38.2023 (Global Digital Health Certification Network) circular letter references added to Overview (Arabic, Chinese, English, French, Russian)
* Trust Network Gateway Letters of Application added for all languages (English, Arabic, French, Mandarin, Russian, Spanish) and PH4H
* Updated Participant onboarding list

### 2026-07-23 v1.6.0 - release

* Nightly participant generation fixes: 
* Fixed GitHub API rate limiting in the nightly participant generation workflow
* Fixed missing Participants CodeSystem updates
 
* Additional updates: 
* Clarified that the HCERT CWT must include the signature for validation
* Updated FSH model definitions for cardinality on CWT, and HCERT configuration
 

### 2026-07-29 v1.7.0 - release

* Nightly participant generation fixes: 
* Fixed GitHub API rate limiting in the nightly participant generation workflow
* Fixed missing Participants
 
* Added MedicationOverviewMin as a new payload type in HCERT

### 2026-08-27 v1.7.1 - release

* updated GDHCN Participants onboarding status

### 2026-09-03 v1.7.2 - release

* updated GDHCN Administrative and Operational Framework letter

### 2026-10-01 v1.7.3 - release

* Added GDHCN Administrative and Operational Framework as a top-level menu item next to Home
* Updated GDHCN Administrative and Operational Framework document
* Updated GDHCN Participants onboarding status
* Participant lists updated

### 2026-10-09 v1.7.4 - release

* Updated GDHCN Administrative and Operational Framework document

