# GDHCNParticipantDID-SMR-DEV-DSC - WHO SMART Trust v1.7.4

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-SMR-DEV-DSC**

## Endpoint: GDHCNParticipantDID-SMR-DEV-DSC

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

San Marino Trustlist (DID v2) - DEV - Document Signing Certificates did:web:tng-cdn.who.int:v2:trustlist:-:SMR:DSC resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/SMR/DSC/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:SMR:DSC

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:SMR:DSC |
| Connection Type: |  |
| Managed By: | [San Marino (Government)](Organization-GDHCNParticipant-SMR-DEV.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-SMR-DEV-DSC",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "San Marino Trustlist (DID v2) - DEV - Document Signing Certificates\ndid:web:tng-cdn.who.int:v2:trustlist:-:SMR:DSC\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/SMR/DSC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-SMR-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:SMR:DSC"
}

```
