# GDHCNParticipantDID-XXI-DEV-All - WHO SMART Trust v1.7.4

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-XXI-DEV-All**

## Endpoint: GDHCNParticipantDID-XXI-DEV-All

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

California Trustlist (DID v2) - DEV - All keys did:web:tng-cdn.who.int:v2:trustlist:-:XXI resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XXI/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:XXI

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:XXI |
| Connection Type: |  |
| Managed By: | [California (Government)](Organization-GDHCNParticipant-XXI-DEV.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-XXI-DEV-All",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "California Trustlist (DID v2) - DEV - All keys\ndid:web:tng-cdn.who.int:v2:trustlist:-:XXI\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XXI/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-XXI-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:XXI"
}

```
