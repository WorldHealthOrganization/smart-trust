# GDHCNParticipantDID-XCL-DEV-All - WHO SMART Trust v1.7.4

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-XCL-DEV-All**

## Endpoint: GDHCNParticipantDID-XCL-DEV-All

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

California Trustlist (DID v2) - DEV - All keys did:web:tng-cdn.who.int:v2:trustlist:-:XCL resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XCL/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:XCL

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:XCL |
| Connection Type: |  |
| Managed By: | [California (Government)](Organization-GDHCNParticipant-XCL-DEV.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-XCL-DEV-All",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "California Trustlist (DID v2) - DEV - All keys\ndid:web:tng-cdn.who.int:v2:trustlist:-:XCL\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XCL/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-XCL-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:XCL"
}

```
