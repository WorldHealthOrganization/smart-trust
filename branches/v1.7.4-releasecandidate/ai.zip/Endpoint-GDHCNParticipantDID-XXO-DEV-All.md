# GDHCNParticipantDID-XXO-DEV-All - WHO SMART Trust v1.7.4

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-XXO-DEV-All**

## Endpoint: GDHCNParticipantDID-XXO-DEV-All

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

DEV Participant XXO Trustlist (DID v2) - DEV - All keys did:web:tng-cdn.who.int:v2:trustlist:-:XXO resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XXO/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:XXO

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:XXO |
| Connection Type: |  |
| Managed By: | [DEV Participant XXO (Government)](Organization-GDHCNParticipant-XXO-DEV.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-XXO-DEV-All",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "DEV Participant XXO Trustlist (DID v2) - DEV - All keys\ndid:web:tng-cdn.who.int:v2:trustlist:-:XXO\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XXO/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-XXO-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:XXO"
}

```
