# WHO GDHCN Trust Network Participant - DEV - WHO SMART Trust v1.7.4

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **WHO GDHCN Trust Network Participant - DEV**

## CodeSystem: WHO GDHCN Trust Network Participant - DEV (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/trust/CodeSystems/Participants-DEV | *Version*:1.7.4 |
| Active as of 2026-10-09 | *Computable Name*:Participants-DEV |

 
CodeSystem for GDHCN Trust Network Participants for Development environment 

 This Code system is referenced in the content logical definition of the following value sets: 

* [WHO GDHCN Trust Network Participant - DEV](ValueSet-Participants-DEV.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "Participants-DEV",
  "url" : "http://smart.who.int/trust/CodeSystems/Participants-DEV",
  "version" : "1.7.4",
  "name" : "Participants-DEV",
  "title" : "WHO GDHCN Trust Network Participant - DEV",
  "status" : "active",
  "experimental" : true,
  "date" : "2026-10-09T13:27:33+00:00",
  "publisher" : "WHO",
  "contact" : [{
    "name" : "WHO",
    "telecom" : [{
      "system" : "url",
      "value" : "http://who.int"
    }]
  }],
  "description" : "CodeSystem for GDHCN Trust Network Participants for Development environment",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "http://unstats.un.org/unsd/methods/m49/m49.htm",
      "code" : "001"
    }]
  }],
  "caseSensitive" : false,
  "content" : "complete",
  "count" : 25,
  "concept" : [{
    "code" : "IOM",
    "display" : "TEST"
  },
  {
    "code" : "WHO",
    "display" : "DEV Participant WHO"
  },
  {
    "code" : "XCL",
    "display" : "California"
  },
  {
    "code" : "XML",
    "display" : "GDHCN entomo"
  },
  {
    "code" : "XXA",
    "display" : "Geneva"
  },
  {
    "code" : "XXB",
    "display" : "TEST"
  },
  {
    "code" : "XXC",
    "display" : "TEST"
  },
  {
    "code" : "XXD",
    "display" : "CENS XD"
  },
  {
    "code" : "XXE",
    "display" : "Geneva XE"
  },
  {
    "code" : "XXF",
    "display" : "Test Locality XF"
  },
  {
    "code" : "XXG",
    "display" : "Geneva"
  },
  {
    "code" : "XXH",
    "display" : "Geneva"
  },
  {
    "code" : "XXI",
    "display" : "California"
  },
  {
    "code" : "XXJ",
    "display" : "DEV Participant XXJ"
  },
  {
    "code" : "XXK",
    "display" : "Rengo"
  },
  {
    "code" : "XXN",
    "display" : "DEV Participant XXN"
  },
  {
    "code" : "XXO",
    "display" : "DEV Participant XXO"
  },
  {
    "code" : "XXP",
    "display" : "Geneva"
  },
  {
    "code" : "XXQ",
    "display" : "Test Locality"
  },
  {
    "code" : "XXT",
    "display" : "Geneva"
  },
  {
    "code" : "XXU",
    "display" : "Geneva"
  },
  {
    "code" : "XXV",
    "display" : "TEST CITY"
  },
  {
    "code" : "XXW",
    "display" : "Test Locality"
  },
  {
    "code" : "XXX",
    "display" : "Warrandyte"
  },
  {
    "code" : "XYK",
    "display" : "Test"
  }]
}

```
