# GDHCNParticipantDID-AND-DSC - WHO SMART Trust v1.7.4

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-AND-DSC**

## Endpoint: GDHCNParticipantDID-AND-DSC

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Andorra Trustlist (DID v2) - Document Signing Certificates did:web:tng-cdn.who.int:v2:trustlist:-:AND:DSC resolvable at https://tng-cdn.who.int/v2/trustlist/-/AND/DSC/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:AND:DSC

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:AND:DSC |
| Connection Type: |  |
| Managed By: | [Andorra (Government)](Organization-GDHCNParticipant-AND.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-AND-DSC",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Andorra Trustlist (DID v2) - Document Signing Certificates\ndid:web:tng-cdn.who.int:v2:trustlist:-:AND:DSC\nresolvable at https://tng-cdn.who.int/v2/trustlist/-/AND/DSC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-AND"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:AND:DSC"
}

```
