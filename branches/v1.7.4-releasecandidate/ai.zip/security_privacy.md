# Security and Privacy Considerations - WHO SMART Trust v1.7.4

* [**Table of Contents**](toc.md)
* [**Deployment**](deployment.md)
* **Security and Privacy Considerations**

## Security and Privacy Considerations

### Security and Privacy Considerations

