# GDHCNParticipantDID-XXP-DEV-SCA - WHO SMART Trust v1.7.4

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-XXP-DEV-SCA**

## Endpoint: GDHCNParticipantDID-XXP-DEV-SCA

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Geneva Trustlist (DID v2) - DEV - Certificate Signing Authority did:web:tng-cdn.who.int:v2:trustlist:-:XXP:SCA resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XXP/SCA/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:XXP:SCA

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:XXP:SCA |
| Connection Type: |  |
| Managed By: | [Geneva (Government)](Organization-GDHCNParticipant-XXP-DEV.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-XXP-DEV-SCA",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Geneva Trustlist (DID v2) - DEV - Certificate Signing Authority\ndid:web:tng-cdn.who.int:v2:trustlist:-:XXP:SCA\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XXP/SCA/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-XXP-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:XXP:SCA"
}

```
