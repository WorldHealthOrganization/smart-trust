# GDHCNParticipantDID-IOM-UAT-SCA - WHO SMART Trust v1.7.4

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-IOM-UAT-SCA**

## Endpoint: GDHCNParticipantDID-IOM-UAT-SCA

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

IOM Trustlist (DID v2) - UAT - Certificate Signing Authority did:web:tng-cdn.who.int:v2:trustlist:-:IOM:SCA resolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/IOM/SCA/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:IOM:SCA

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:IOM:SCA |
| Connection Type: |  |
| Managed By: | [IOM (Government)](Organization-GDHCNParticipant-IOM-UAT.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-IOM-UAT-SCA",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "IOM Trustlist (DID v2) - UAT - Certificate Signing Authority\ndid:web:tng-cdn.who.int:v2:trustlist:-:IOM:SCA\nresolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/IOM/SCA/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-IOM-UAT"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:IOM:SCA"
}

```
