# GDHCNParticipantDID-SLV-DEV-DSC - WHO SMART Trust v1.7.4

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-SLV-DEV-DSC**

## Endpoint: GDHCNParticipantDID-SLV-DEV-DSC

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

El Salvador Trustlist (DID v2) - DEV - Document Signing Certificates did:web:tng-cdn.who.int:v2:trustlist:-:SLV:DSC resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/SLV/DSC/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:SLV:DSC

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:SLV:DSC |
| Connection Type: |  |
| Managed By: | [El Salvador (Government)](Organization-GDHCNParticipant-SLV-DEV.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-SLV-DEV-DSC",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "El Salvador Trustlist (DID v2) - DEV - Document Signing Certificates\ndid:web:tng-cdn.who.int:v2:trustlist:-:SLV:DSC\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/SLV/DSC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-SLV-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:SLV:DSC"
}

```
