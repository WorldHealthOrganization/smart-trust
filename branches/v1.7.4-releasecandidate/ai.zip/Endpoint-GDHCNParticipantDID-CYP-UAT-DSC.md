# GDHCNParticipantDID-CYP-UAT-DSC - WHO SMART Trust v1.7.4

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-CYP-UAT-DSC**

## Endpoint: GDHCNParticipantDID-CYP-UAT-DSC

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Cyprus Trustlist (DID v2) - UAT - Document Signing Certificates did:web:tng-cdn.who.int:v2:trustlist:-:CYP:DSC resolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/CYP/DSC/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:CYP:DSC

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:CYP:DSC |
| Connection Type: |  |
| Managed By: | [Cyprus (Government)](Organization-GDHCNParticipant-CYP-UAT.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-CYP-UAT-DSC",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Cyprus Trustlist (DID v2) - UAT - Document Signing Certificates\ndid:web:tng-cdn.who.int:v2:trustlist:-:CYP:DSC\nresolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/CYP/DSC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-CYP-UAT"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:CYP:DSC"
}

```
