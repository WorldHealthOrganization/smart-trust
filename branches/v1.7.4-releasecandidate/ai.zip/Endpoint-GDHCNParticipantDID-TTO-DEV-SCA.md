# GDHCNParticipantDID-TTO-DEV-SCA - WHO SMART Trust v1.7.4

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-TTO-DEV-SCA**

## Endpoint: GDHCNParticipantDID-TTO-DEV-SCA

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Trinidad and Tobago Trustlist (DID v2) - DEV - Certificate Signing Authority did:web:tng-cdn.who.int:v2:trustlist:-:TTO:SCA resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/TTO/SCA/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:TTO:SCA

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:TTO:SCA |
| Connection Type: |  |
| Managed By: | [Trinidad and Tobago (Government)](Organization-GDHCNParticipant-TTO-DEV.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-TTO-DEV-SCA",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Trinidad and Tobago Trustlist (DID v2) - DEV - Certificate Signing Authority\ndid:web:tng-cdn.who.int:v2:trustlist:-:TTO:SCA\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/TTO/SCA/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-TTO-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:TTO:SCA"
}

```
