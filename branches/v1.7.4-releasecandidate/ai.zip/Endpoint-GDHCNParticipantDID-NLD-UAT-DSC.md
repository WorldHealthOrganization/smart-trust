# GDHCNParticipantDID-NLD-UAT-DSC - WHO SMART Trust v1.7.4

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-NLD-UAT-DSC**

## Endpoint: GDHCNParticipantDID-NLD-UAT-DSC

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Netherlands (Kingdom of the) Trustlist (DID v2) - UAT - Document Signing Certificates did:web:tng-cdn.who.int:v2:trustlist:-:NLD:DSC resolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/NLD/DSC/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:NLD:DSC

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:NLD:DSC |
| Connection Type: |  |
| Managed By: | [Netherlands (Kingdom of the) (Government)](Organization-GDHCNParticipant-NLD-UAT.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-NLD-UAT-DSC",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Netherlands (Kingdom of the) Trustlist (DID v2) - UAT - Document Signing Certificates\ndid:web:tng-cdn.who.int:v2:trustlist:-:NLD:DSC\nresolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/NLD/DSC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-NLD-UAT"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:NLD:DSC"
}

```
