# GDHCNParticipantDID-ARM-DEV-DSC - WHO SMART Trust v1.7.4

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-ARM-DEV-DSC**

## Endpoint: GDHCNParticipantDID-ARM-DEV-DSC

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Armenia Trustlist (DID v2) - DEV - Document Signing Certificates did:web:tng-cdn.who.int:v2:trustlist:-:ARM:DSC resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/ARM/DSC/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:ARM:DSC

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:ARM:DSC |
| Connection Type: |  |
| Managed By: | [Armenia (Government)](Organization-GDHCNParticipant-ARM-DEV.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-ARM-DEV-DSC",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Armenia Trustlist (DID v2) - DEV - Document Signing Certificates\ndid:web:tng-cdn.who.int:v2:trustlist:-:ARM:DSC\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/ARM/DSC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-ARM-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:ARM:DSC"
}

```
