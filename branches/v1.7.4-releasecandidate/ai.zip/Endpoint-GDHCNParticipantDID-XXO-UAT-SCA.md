# GDHCNParticipantDID-XXO-UAT-SCA - WHO SMART Trust v1.7.4

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-XXO-UAT-SCA**

## Endpoint: GDHCNParticipantDID-XXO-UAT-SCA

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

UAT Participant XXO Trustlist (DID v2) - UAT - Certificate Signing Authority did:web:tng-cdn.who.int:v2:trustlist:-:XXO:SCA resolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/XXO/SCA/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:XXO:SCA

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:XXO:SCA |
| Connection Type: |  |
| Managed By: | [UAT Participant XXO (Government)](Organization-GDHCNParticipant-XXO-UAT.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-XXO-UAT-SCA",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "UAT Participant XXO Trustlist (DID v2) - UAT - Certificate Signing Authority\ndid:web:tng-cdn.who.int:v2:trustlist:-:XXO:SCA\nresolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/XXO/SCA/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-XXO-UAT"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:XXO:SCA"
}

```
