# GDHCNParticipantDID-FRO-UAT-All - WHO SMART Trust v1.7.4

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-FRO-UAT-All**

## Endpoint: GDHCNParticipantDID-FRO-UAT-All

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Faroe Islands Trustlist (DID v2) - UAT - All keys did:web:tng-cdn.who.int:v2:trustlist:-:FRO resolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/FRO/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:FRO

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:FRO |
| Connection Type: |  |
| Managed By: | [Faroe Islands (Government)](Organization-GDHCNParticipant-FRO-UAT.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-FRO-UAT-All",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Faroe Islands Trustlist (DID v2) - UAT - All keys\ndid:web:tng-cdn.who.int:v2:trustlist:-:FRO\nresolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/FRO/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-FRO-UAT"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:FRO"
}

```
