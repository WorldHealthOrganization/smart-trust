# GDHCNParticipantDID-ALB-UAT-SCA - WHO SMART Trust v1.7.4

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-ALB-UAT-SCA**

## Endpoint: GDHCNParticipantDID-ALB-UAT-SCA

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Albania Trustlist (DID v2) - UAT - Certificate Signing Authority did:web:tng-cdn.who.int:v2:trustlist:-:ALB:SCA resolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/ALB/SCA/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:ALB:SCA

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:ALB:SCA |
| Connection Type: |  |
| Managed By: | [Albania (Government)](Organization-GDHCNParticipant-ALB-UAT.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-ALB-UAT-SCA",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Albania Trustlist (DID v2) - UAT - Certificate Signing Authority\ndid:web:tng-cdn.who.int:v2:trustlist:-:ALB:SCA\nresolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/ALB/SCA/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-ALB-UAT"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:ALB:SCA"
}

```
