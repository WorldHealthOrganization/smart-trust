# GDHCNParticipantDID-SGP-UAT-All - WHO SMART Trust v1.7.4

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-SGP-UAT-All**

## Endpoint: GDHCNParticipantDID-SGP-UAT-All

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Singapore Trustlist (DID v2) - UAT - All keys did:web:tng-cdn.who.int:v2:trustlist:-:SGP resolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/SGP/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:SGP

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:SGP |
| Connection Type: |  |
| Managed By: | [Singapore (Government)](Organization-GDHCNParticipant-SGP-UAT.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-SGP-UAT-All",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Singapore Trustlist (DID v2) - UAT - All keys\ndid:web:tng-cdn.who.int:v2:trustlist:-:SGP\nresolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/SGP/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-SGP-UAT"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:SGP"
}

```
