# GDHCNParticipantDID-CZE-DSC - WHO SMART Trust v1.7.4

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-CZE-DSC**

## Endpoint: GDHCNParticipantDID-CZE-DSC

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Czechia Trustlist (DID v2) - Document Signing Certificates did:web:tng-cdn.who.int:v2:trustlist:-:CZE:DSC resolvable at https://tng-cdn.who.int/v2/trustlist/-/CZE/DSC/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:CZE:DSC

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:CZE:DSC |
| Connection Type: |  |
| Managed By: | [Czechia (Government)](Organization-GDHCNParticipant-CZE.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-CZE-DSC",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Czechia Trustlist (DID v2) - Document Signing Certificates\ndid:web:tng-cdn.who.int:v2:trustlist:-:CZE:DSC\nresolvable at https://tng-cdn.who.int/v2/trustlist/-/CZE/DSC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-CZE"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:CZE:DSC"
}

```
