# GDHCNParticipantDID-TGO-DEV-SCA - WHO SMART Trust v1.7.4

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-TGO-DEV-SCA**

## Endpoint: GDHCNParticipantDID-TGO-DEV-SCA

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Togo Trustlist (DID v2) - DEV - Certificate Signing Authority did:web:tng-cdn.who.int:v2:trustlist:-:TGO:SCA resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/TGO/SCA/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:TGO:SCA

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:TGO:SCA |
| Connection Type: |  |
| Managed By: | [Togo (Government)](Organization-GDHCNParticipant-TGO-DEV.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-TGO-DEV-SCA",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Togo Trustlist (DID v2) - DEV - Certificate Signing Authority\ndid:web:tng-cdn.who.int:v2:trustlist:-:TGO:SCA\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/TGO/SCA/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-TGO-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:TGO:SCA"
}

```
