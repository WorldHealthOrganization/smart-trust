# GDHCNParticipantDID-ARE-DEV-SCA - WHO SMART Trust v1.7.4

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-ARE-DEV-SCA**

## Endpoint: GDHCNParticipantDID-ARE-DEV-SCA

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

United Arab Emirates Trustlist (DID v2) - DEV - Certificate Signing Authority did:web:tng-cdn.who.int:v2:trustlist:-:ARE:SCA resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/ARE/SCA/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:ARE:SCA

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:ARE:SCA |
| Connection Type: |  |
| Managed By: | [United Arab Emirates (Government)](Organization-GDHCNParticipant-ARE-DEV.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-ARE-DEV-SCA",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "United Arab Emirates Trustlist (DID v2) - DEV - Certificate Signing Authority\ndid:web:tng-cdn.who.int:v2:trustlist:-:ARE:SCA\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/ARE/SCA/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-ARE-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:ARE:SCA"
}

```
