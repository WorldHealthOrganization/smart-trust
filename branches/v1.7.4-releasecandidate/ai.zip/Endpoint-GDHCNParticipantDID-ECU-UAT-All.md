# GDHCNParticipantDID-ECU-UAT-All - WHO SMART Trust v1.7.4

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-ECU-UAT-All**

## Endpoint: GDHCNParticipantDID-ECU-UAT-All

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Ecuador Trustlist (DID v2) - UAT - All keys did:web:tng-cdn.who.int:v2:trustlist:-:ECU resolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/ECU/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:ECU

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:ECU |
| Connection Type: |  |
| Managed By: | [Ecuador (Government)](Organization-GDHCNParticipant-ECU-UAT.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-ECU-UAT-All",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Ecuador Trustlist (DID v2) - UAT - All keys\ndid:web:tng-cdn.who.int:v2:trustlist:-:ECU\nresolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/ECU/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-ECU-UAT"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:ECU"
}

```
