# GDHCNParticipantDID-BEN-UAT-All - WHO SMART Trust v1.7.4

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-BEN-UAT-All**

## Endpoint: GDHCNParticipantDID-BEN-UAT-All

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Benin Trustlist (DID v2) - UAT - All keys did:web:tng-cdn.who.int:v2:trustlist:-:BEN resolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/BEN/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:BEN

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:BEN |
| Connection Type: |  |
| Managed By: | [Benin (Government)](Organization-GDHCNParticipant-BEN-UAT.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-BEN-UAT-All",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Benin Trustlist (DID v2) - UAT - All keys\ndid:web:tng-cdn.who.int:v2:trustlist:-:BEN\nresolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/BEN/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-BEN-UAT"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:BEN"
}

```
