# GDHCNParticipantDID-XML-DEV-SCA - WHO SMART Trust v1.7.4

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-XML-DEV-SCA**

## Endpoint: GDHCNParticipantDID-XML-DEV-SCA

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

GDHCN entomo Trustlist (DID v2) - DEV - Certificate Signing Authority did:web:tng-cdn.who.int:v2:trustlist:-:XML:SCA resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XML/SCA/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:XML:SCA

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:XML:SCA |
| Connection Type: |  |
| Managed By: | [GDHCN entomo (Government)](Organization-GDHCNParticipant-XML-DEV.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-XML-DEV-SCA",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "GDHCN entomo Trustlist (DID v2) - DEV - Certificate Signing Authority\ndid:web:tng-cdn.who.int:v2:trustlist:-:XML:SCA\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XML/SCA/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-XML-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:XML:SCA"
}

```
