# GDHCNParticipantDID-CAN-UAT-All - WHO SMART Trust v1.7.4

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-CAN-UAT-All**

## Endpoint: GDHCNParticipantDID-CAN-UAT-All

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Canada Trustlist (DID v2) - UAT - All keys did:web:tng-cdn.who.int:v2:trustlist:-:CAN resolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/CAN/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:CAN

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:CAN |
| Connection Type: |  |
| Managed By: | [Canada (Government)](Organization-GDHCNParticipant-CAN-UAT.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-CAN-UAT-All",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Canada Trustlist (DID v2) - UAT - All keys\ndid:web:tng-cdn.who.int:v2:trustlist:-:CAN\nresolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/CAN/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-CAN-UAT"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:CAN"
}

```
