# GDHCNParticipantDID-LVA-DEV-All - WHO SMART Trust v1.7.4

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-LVA-DEV-All**

## Endpoint: GDHCNParticipantDID-LVA-DEV-All

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Latvia Trustlist (DID v2) - DEV - All keys did:web:tng-cdn.who.int:v2:trustlist:-:LVA resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/LVA/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:LVA

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:LVA |
| Connection Type: |  |
| Managed By: | [Latvia (Government)](Organization-GDHCNParticipant-LVA-DEV.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-LVA-DEV-All",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Latvia Trustlist (DID v2) - DEV - All keys\ndid:web:tng-cdn.who.int:v2:trustlist:-:LVA\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/LVA/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-LVA-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:LVA"
}

```
