# GDHCNParticipantDID-XXO-DEV-DSC - WHO SMART Trust v1.7.4

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-XXO-DEV-DSC**

## Endpoint: GDHCNParticipantDID-XXO-DEV-DSC

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

DEV Participant XXO Trustlist (DID v2) - DEV - Document Signing Certificates did:web:tng-cdn.who.int:v2:trustlist:-:XXO:DSC resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XXO/DSC/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:XXO:DSC

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:XXO:DSC |
| Connection Type: |  |
| Managed By: | [DEV Participant XXO (Government)](Organization-GDHCNParticipant-XXO-DEV.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-XXO-DEV-DSC",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "DEV Participant XXO Trustlist (DID v2) - DEV - Document Signing Certificates\ndid:web:tng-cdn.who.int:v2:trustlist:-:XXO:DSC\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XXO/DSC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-XXO-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:XXO:DSC"
}

```
