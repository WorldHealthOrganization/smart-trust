# GDHCNParticipantDID-USA-DEV-SCA - WHO SMART Trust v1.7.4

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-USA-DEV-SCA**

## Endpoint: GDHCNParticipantDID-USA-DEV-SCA

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

United States of America Trustlist (DID v2) - DEV - Certificate Signing Authority did:web:tng-cdn.who.int:v2:trustlist:-:USA:SCA resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/USA/SCA/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:USA:SCA

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:USA:SCA |
| Connection Type: |  |
| Managed By: | [United States of America (Government)](Organization-GDHCNParticipant-USA-DEV.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-USA-DEV-SCA",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "United States of America Trustlist (DID v2) - DEV - Certificate Signing Authority\ndid:web:tng-cdn.who.int:v2:trustlist:-:USA:SCA\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/USA/SCA/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-USA-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:USA:SCA"
}

```
