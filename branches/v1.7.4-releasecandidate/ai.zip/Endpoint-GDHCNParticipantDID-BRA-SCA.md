# GDHCNParticipantDID-BRA-SCA - WHO SMART Trust v1.7.4

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-BRA-SCA**

## Endpoint: GDHCNParticipantDID-BRA-SCA

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Brazil Trustlist (DID v2) - Certificate Signing Authority did:web:tng-cdn.who.int:v2:trustlist:-:BRA:SCA resolvable at https://tng-cdn.who.int/v2/trustlist/-/BRA/SCA/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:BRA:SCA

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:BRA:SCA |
| Connection Type: |  |
| Managed By: | [Brazil (Government)](Organization-GDHCNParticipant-BRA.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-BRA-SCA",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Brazil Trustlist (DID v2) - Certificate Signing Authority\ndid:web:tng-cdn.who.int:v2:trustlist:-:BRA:SCA\nresolvable at https://tng-cdn.who.int/v2/trustlist/-/BRA/SCA/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-BRA"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:BRA:SCA"
}

```
