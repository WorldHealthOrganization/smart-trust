# GDHCNParticipantDID-SVN-UAT-SCA - WHO SMART Trust v1.7.4

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-SVN-UAT-SCA**

## Endpoint: GDHCNParticipantDID-SVN-UAT-SCA

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Slovenia Trustlist (DID v2) - UAT - Certificate Signing Authority did:web:tng-cdn.who.int:v2:trustlist:-:SVN:SCA resolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/SVN/SCA/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:SVN:SCA

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:SVN:SCA |
| Connection Type: |  |
| Managed By: | [Slovenia (Government)](Organization-GDHCNParticipant-SVN-UAT.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-SVN-UAT-SCA",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Slovenia Trustlist (DID v2) - UAT - Certificate Signing Authority\ndid:web:tng-cdn.who.int:v2:trustlist:-:SVN:SCA\nresolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/SVN/SCA/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-SVN-UAT"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:SVN:SCA"
}

```
