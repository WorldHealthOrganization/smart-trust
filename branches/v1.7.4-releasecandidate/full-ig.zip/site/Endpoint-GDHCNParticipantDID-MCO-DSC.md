# GDHCNParticipantDID-MCO-DSC - WHO SMART Trust v1.7.4

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-MCO-DSC**

## Endpoint: GDHCNParticipantDID-MCO-DSC

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Monaco Trustlist (DID v2) - Document Signing Certificates did:web:tng-cdn.who.int:v2:trustlist:-:MCO:DSC resolvable at https://tng-cdn.who.int/v2/trustlist/-/MCO/DSC/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:MCO:DSC

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:MCO:DSC |
| Connection Type: |  |
| Managed By: | [Monaco (Government)](Organization-GDHCNParticipant-MCO.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-MCO-DSC",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Monaco Trustlist (DID v2) - Document Signing Certificates\ndid:web:tng-cdn.who.int:v2:trustlist:-:MCO:DSC\nresolvable at https://tng-cdn.who.int/v2/trustlist/-/MCO/DSC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-MCO"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:MCO:DSC"
}

```
