# GDHCNParticipantDID-XXF-DEV-All - WHO SMART Trust v1.7.4

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-XXF-DEV-All**

## Endpoint: GDHCNParticipantDID-XXF-DEV-All

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Test Locality XF Trustlist (DID v2) - DEV - All keys did:web:tng-cdn.who.int:v2:trustlist:-:XXF resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XXF/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:XXF

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:XXF |
| Connection Type: |  |
| Managed By: | [Test Locality XF (Government)](Organization-GDHCNParticipant-XXF-DEV.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-XXF-DEV-All",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Test Locality XF Trustlist (DID v2) - DEV - All keys\ndid:web:tng-cdn.who.int:v2:trustlist:-:XXF\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XXF/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-XXF-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:XXF"
}

```
