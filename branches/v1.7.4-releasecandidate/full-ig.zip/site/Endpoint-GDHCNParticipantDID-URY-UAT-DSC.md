# GDHCNParticipantDID-URY-UAT-DSC - WHO SMART Trust v1.7.4

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-URY-UAT-DSC**

## Endpoint: GDHCNParticipantDID-URY-UAT-DSC

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Uruguay Trustlist (DID v2) - UAT - Document Signing Certificates did:web:tng-cdn.who.int:v2:trustlist:-:URY:DSC resolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/URY/DSC/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:URY:DSC

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:URY:DSC |
| Connection Type: |  |
| Managed By: | [Uruguay (Government)](Organization-GDHCNParticipant-URY-UAT.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-URY-UAT-DSC",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Uruguay Trustlist (DID v2) - UAT - Document Signing Certificates\ndid:web:tng-cdn.who.int:v2:trustlist:-:URY:DSC\nresolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/URY/DSC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-URY-UAT"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:URY:DSC"
}

```
