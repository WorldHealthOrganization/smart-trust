# GDHCNParticipantDID-IOM-UAT-All - WHO SMART Trust v1.7.4

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-IOM-UAT-All**

## Endpoint: GDHCNParticipantDID-IOM-UAT-All

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

IOM Trustlist (DID v2) - UAT - All keys did:web:tng-cdn.who.int:v2:trustlist:-:IOM resolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/IOM/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:IOM

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:IOM |
| Connection Type: |  |
| Managed By: | [IOM (Government)](Organization-GDHCNParticipant-IOM-UAT.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-IOM-UAT-All",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "IOM Trustlist (DID v2) - UAT - All keys\ndid:web:tng-cdn.who.int:v2:trustlist:-:IOM\nresolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/IOM/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-IOM-UAT"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:IOM"
}

```
