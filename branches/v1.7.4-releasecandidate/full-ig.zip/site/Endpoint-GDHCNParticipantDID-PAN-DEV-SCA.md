# GDHCNParticipantDID-PAN-DEV-SCA - WHO SMART Trust v1.7.4

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-PAN-DEV-SCA**

## Endpoint: GDHCNParticipantDID-PAN-DEV-SCA

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Panama Trustlist (DID v2) - DEV - Certificate Signing Authority did:web:tng-cdn.who.int:v2:trustlist:-:PAN:SCA resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/PAN/SCA/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:PAN:SCA

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:PAN:SCA |
| Connection Type: |  |
| Managed By: | [Panama (Government)](Organization-GDHCNParticipant-PAN-DEV.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-PAN-DEV-SCA",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Panama Trustlist (DID v2) - DEV - Certificate Signing Authority\ndid:web:tng-cdn.who.int:v2:trustlist:-:PAN:SCA\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/PAN/SCA/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-PAN-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:PAN:SCA"
}

```
