# GDHCNParticipantDID-OMN-DEV-All - WHO SMART Trust v1.7.4

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-OMN-DEV-All**

## Endpoint: GDHCNParticipantDID-OMN-DEV-All

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Oman Trustlist (DID v2) - DEV - All keys did:web:tng-cdn.who.int:v2:trustlist:-:OMN resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/OMN/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:OMN

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:OMN |
| Connection Type: |  |
| Managed By: | [Oman (Government)](Organization-GDHCNParticipant-OMN-DEV.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-OMN-DEV-All",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Oman Trustlist (DID v2) - DEV - All keys\ndid:web:tng-cdn.who.int:v2:trustlist:-:OMN\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/OMN/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-OMN-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:OMN"
}

```
