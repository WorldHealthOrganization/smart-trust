# GDHCNParticipantDID-WHO - WHO SMART Trust v1.7.4

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-WHO**

## Endpoint: GDHCNParticipantDID-WHO

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

WHO Trust List (DID v2) (): http://tng-cdn.who.int/v2/trustlist/-/WHO/did.json

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | [http://tng-cdn.who.int/v2/trustlist/-/WHO/did.json](http://tng-cdn.who.int/v2/trustlist/-/WHO/did.json) |
| Connection Type: |  |
| Managed By: | [WHO (Government)](Organization-GDHCNParticipant-WHO.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-WHO",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "WHO Trust List (DID v2)",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-WHO"
  },
  "address" : "http://tng-cdn.who.int/v2/trustlist/-/WHO/did.json"
}

```
