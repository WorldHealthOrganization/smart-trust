# GDHCNParticipantDID-XXX-DEV-SCA - WHO SMART Trust v1.7.4

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-XXX-DEV-SCA**

## Endpoint: GDHCNParticipantDID-XXX-DEV-SCA

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Warrandyte Trustlist (DID v2) - DEV - Certificate Signing Authority did:web:tng-cdn.who.int:v2:trustlist:-:XXX:SCA resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XXX/SCA/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:XXX:SCA

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:XXX:SCA |
| Connection Type: |  |
| Managed By: | [Warrandyte (Government)](Organization-GDHCNParticipant-XXX-DEV.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-XXX-DEV-SCA",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Warrandyte Trustlist (DID v2) - DEV - Certificate Signing Authority\ndid:web:tng-cdn.who.int:v2:trustlist:-:XXX:SCA\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XXX/SCA/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-XXX-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:XXX:SCA"
}

```
