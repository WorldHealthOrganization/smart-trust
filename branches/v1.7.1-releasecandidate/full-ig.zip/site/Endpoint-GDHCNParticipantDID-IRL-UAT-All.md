# GDHCNParticipantDID-IRL-UAT-All - WHO SMART Trust v1.7.1

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-IRL-UAT-All**

## Endpoint: GDHCNParticipantDID-IRL-UAT-All

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: Ireland Trustlist (DID v2) - UAT - All keys did:web:tng-cdn.who.int:v2:trustlist:-:IRL resolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/IRL/did.json

**managingOrganization**: [Organization Ireland](Organization-GDHCNParticipant-IRL-UAT.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:IRL



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-IRL-UAT-All",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Ireland Trustlist (DID v2) - UAT - All keys\ndid:web:tng-cdn.who.int:v2:trustlist:-:IRL\nresolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/IRL/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-IRL-UAT"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:IRL"
}

```
