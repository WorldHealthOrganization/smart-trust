# GDHCNParticipant-SLV-UAT - WHO SMART Trust v1.7.1

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipant-SLV-UAT**

## Organization: GDHCNParticipant-SLV-UAT

Profile: [mCSD Organization](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Organization.html)

**type**: Government

**name**: El Salvador

**endpoint**: 

* [Endpoint El Salvador Trustlist (DID v2) - UAT - All keys did:web:tng-cdn.who.int:v2:trustlist:-:SLV resolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/SLV/did.json](Endpoint-GDHCNParticipantDID-SLV-UAT-All.md)
* [Endpoint El Salvador Trustlist (DID v2) - UAT - Document Signing Certificates did:web:tng-cdn.who.int:v2:trustlist:-:SLV:DSC resolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/SLV/DSC/did.json](Endpoint-GDHCNParticipantDID-SLV-UAT-DSC.md)
* [Endpoint El Salvador Trustlist (DID v2) - UAT - Certificate Signing Authority did:web:tng-cdn.who.int:v2:trustlist:-:SLV:SCA resolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/SLV/SCA/did.json](Endpoint-GDHCNParticipantDID-SLV-UAT-SCA.md)



## Resource Content

```json
{
  "resourceType" : "Organization",
  "id" : "GDHCNParticipant-SLV-UAT",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Organization"]
  },
  "type" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/organization-type",
      "code" : "govt"
    }]
  }],
  "name" : "El Salvador",
  "endpoint" : [{
    "reference" : "Endpoint/GDHCNParticipantDID-SLV-UAT-All"
  },
  {
    "reference" : "Endpoint/GDHCNParticipantDID-SLV-UAT-DSC"
  },
  {
    "reference" : "Endpoint/GDHCNParticipantDID-SLV-UAT-SCA"
  }]
}

```
