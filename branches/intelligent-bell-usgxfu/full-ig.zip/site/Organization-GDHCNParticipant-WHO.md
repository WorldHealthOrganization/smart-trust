# GDHCNParticipant-WHO - WHO SMART Trust v1.7.5

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipant-WHO**

## Organization: GDHCNParticipant-WHO

Profile: [mCSD Organization](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Organization.html)

WHO (Government)

-------

| | |
| :--- | :--- |
| Type: | Government |



## Resource Content

```json
{
  "resourceType" : "Organization",
  "id" : "GDHCNParticipant-WHO",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Organization"]
  },
  "type" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/organization-type",
      "code" : "govt"
    }]
  }],
  "name" : "WHO"
}

```
