# GDHCNParticipantDID-XXV-DEV-SCA - WHO SMART Trust v1.7.5

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-XXV-DEV-SCA**

## Endpoint: GDHCNParticipantDID-XXV-DEV-SCA

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

TEST CITY Trustlist (DID v2) - DEV - Certificate Signing Authority did:web:tng-cdn.who.int:v2:trustlist:-:XXV:SCA resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XXV/SCA/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:XXV:SCA

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:XXV:SCA |
| Connection Type: |  |
| Managed By: | [TEST CITY (Government)](Organization-GDHCNParticipant-XXV-DEV.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-XXV-DEV-SCA",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "TEST CITY Trustlist (DID v2) - DEV - Certificate Signing Authority\ndid:web:tng-cdn.who.int:v2:trustlist:-:XXV:SCA\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XXV/SCA/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-XXV-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:XXV:SCA"
}

```
