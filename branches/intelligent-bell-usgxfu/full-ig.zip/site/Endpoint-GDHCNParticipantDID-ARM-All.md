# GDHCNParticipantDID-ARM-All - WHO SMART Trust v1.7.5

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-ARM-All**

## Endpoint: GDHCNParticipantDID-ARM-All

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Armenia Trustlist (DID v2) - All keys did:web:tng-cdn.who.int:v2:trustlist:-:ARM resolvable at https://tng-cdn.who.int/v2/trustlist/-/ARM/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:ARM

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:ARM |
| Connection Type: |  |
| Managed By: | [Armenia (Government)](Organization-GDHCNParticipant-ARM.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-ARM-All",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Armenia Trustlist (DID v2) - All keys\ndid:web:tng-cdn.who.int:v2:trustlist:-:ARM\nresolvable at https://tng-cdn.who.int/v2/trustlist/-/ARM/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-ARM"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:ARM"
}

```
