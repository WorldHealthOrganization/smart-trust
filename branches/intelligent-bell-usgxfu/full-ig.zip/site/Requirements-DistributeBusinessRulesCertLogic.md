# Distribute CertLogic business rules - WHO SMART Trust v1.7.5

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Distribute CertLogic business rules**

## Requirements: Distribute CertLogic business rules (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/trust/Requirements/DistributeBusinessRulesCertLogic | *Version*:1.7.5 |
| Active as of 2026-10-22 | *Computable Name*:Distribute CertLogic Business Rules |

 
Make received CertLoigc business rules available through a distrubution point to a Receiver 

* Publisher: Contact Email
  * No publisher has been registered.: No contact email has been registered.
* Publisher: Jurisdiction
  * No publisher has been registered.: 
* Publisher: Statements
  * No publisher has been registered.: 
* Publisher: Derived from
  * No publisher has been registered.: This requirement is not derived from another requriement.
* Publisher: Derivatives
  * No publisher has been registered.: This requirement has the following derivatives:
* Publisher: Participating Actors
  * No publisher has been registered.: 



## Resource Content

```json
{
  "resourceType" : "Requirements",
  "id" : "DistributeBusinessRulesCertLogic",
  "meta" : {
    "profile" : ["http://smart.who.int/base/StructureDefinition/SGRequirements"]
  },
  "extension" : [{
    "url" : "http://smart.who.int/base/StructureDefinition/Satisfies",
    "valueReference" : {
      "reference" : "Requirements/DistributeBusinessRules"
    }
  }],
  "url" : "http://smart.who.int/trust/Requirements/DistributeBusinessRulesCertLogic",
  "version" : "1.7.5",
  "name" : "Distribute CertLogic Business Rules",
  "title" : "Distribute CertLogic business rules",
  "status" : "active",
  "experimental" : true,
  "date" : "2026-10-22T10:46:36+00:00",
  "publisher" : "WHO",
  "contact" : [{
    "name" : "WHO",
    "telecom" : [{
      "system" : "url",
      "value" : "http://who.int"
    }]
  }],
  "description" : "Make received CertLoigc business rules available through a distrubution point to a Receiver",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "http://unstats.un.org/unsd/methods/m49/m49.htm",
      "code" : "001"
    }]
  }],
  "actor" : ["http://smart.who.int/trust/ActorDefinition/TrustNetworkAnchor"]
}

```
