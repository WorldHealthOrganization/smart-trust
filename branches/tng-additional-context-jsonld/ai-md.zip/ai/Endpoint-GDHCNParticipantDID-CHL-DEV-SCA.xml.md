# GDHCNParticipantDID-CHL-DEV-SCA - XML Representation - WHO SMART Trust v1.1.6

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-CHL-DEV-SCA**

WHO SMART Trust, published by WHO. This guide is not an authorized publication; it is the continuous build for version 1.1.6 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/WorldHealthOrganization/smart-trust/tree/tng-additional-context-jsonld](https://github.com/WorldHealthOrganization/smart-trust/tree/tng-additional-context-jsonld) and changes regularly. See the [Directory of published versions](http://smart.who.int/trust/history.html)

*  [Narrative Content](Endpoint-GDHCNParticipantDID-CHL-DEV-SCA.md) 
*  [XML](#) 
*  [JSON](Endpoint-GDHCNParticipantDID-CHL-DEV-SCA.json.md) 
*  [TTL](Endpoint-GDHCNParticipantDID-CHL-DEV-SCA.ttl.md) 

## : GDHCNParticipantDID-CHL-DEV-SCA - XML Representation

[Raw xml](Endpoint-GDHCNParticipantDID-CHL-DEV-SCA.xml) | [Download](Endpoint-GDHCNParticipantDID-CHL-DEV-SCA.xml)

| | | |
| :--- | :--- | :--- |
|  [<prev](Endpoint-GDHCNParticipantDID-CHL-DEV-SCA.md) | [top](#top) |  [next>](Endpoint-GDHCNParticipantDID-CHL-DEV-SCA.json.md) |

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust#1.1.6 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust/history.html)|[License](license.md) 

