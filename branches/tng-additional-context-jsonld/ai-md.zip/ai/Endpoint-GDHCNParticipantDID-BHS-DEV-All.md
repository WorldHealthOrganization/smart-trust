# GDHCNParticipantDID-BHS-DEV-All - WHO SMART Trust v1.1.6

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-BHS-DEV-All**

WHO SMART Trust, published by WHO. This guide is not an authorized publication; it is the continuous build for version 1.1.6 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/WorldHealthOrganization/smart-trust/tree/tng-additional-context-jsonld](https://github.com/WorldHealthOrganization/smart-trust/tree/tng-additional-context-jsonld) and changes regularly. See the [Directory of published versions](http://smart.who.int/trust/history.html)

*  [Narrative Content](#) 
*  [XML](Endpoint-GDHCNParticipantDID-BHS-DEV-All.xml.md) 
*  [JSON](Endpoint-GDHCNParticipantDID-BHS-DEV-All.json.md) 
*  [TTL](Endpoint-GDHCNParticipantDID-BHS-DEV-All.ttl.md) 

## Endpoint: GDHCNParticipantDID-BHS-DEV-All

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: Bahamas Trustlist (DID v2) - DEV - All keys did:web:tng-cdn.who.int:v2:trustlist:-:BHS resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/BHS/did.json

**managingOrganization**: [Organization Bahamas](Organization-GDHCNParticipant-BHS-DEV.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:BHS

| | | |
| :--- | :--- | :--- |
|  [<prev](Endpoint-GDHCNParticipantDID-BEN-UAT-SCA.ttl.md) | [top](#top) |  [next>](Endpoint-GDHCNParticipantDID-BHS-DEV-All.xml.md) |

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust#1.1.6 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust/history.html)|[License](license.md) 

