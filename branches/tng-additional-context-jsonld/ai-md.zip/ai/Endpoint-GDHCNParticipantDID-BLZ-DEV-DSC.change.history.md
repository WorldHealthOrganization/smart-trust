#  - WHO SMART Trust v1.1.6

WHO SMART Trust, published by WHO. This guide is not an authorized publication; it is the continuous build for version 1.1.6 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/WorldHealthOrganization/smart-trust/tree/tng-additional-context-jsonld](https://github.com/WorldHealthOrganization/smart-trust/tree/tng-additional-context-jsonld) and changes regularly. See the [Directory of published versions](http://smart.who.int/trust/history.html)

*  [Narrative Content](Endpoint-GDHCNParticipantDID-BLZ-DEV-DSC.md) 
*  [XML](Endpoint-GDHCNParticipantDID-BLZ-DEV-DSC.xml.md) 
*  [JSON](Endpoint-GDHCNParticipantDID-BLZ-DEV-DSC.json.md) 
*  [TTL](Endpoint-GDHCNParticipantDID-BLZ-DEV-DSC.ttl.md) 

## : Belize Trustlist (DID v2) - DEV - Document Signing Certificates did:web:tng-cdn.who.int:v2:trustlist:-:BLZ:DSC resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/BLZ/DSC/did.json - Change History

History of changes for GDHCNParticipantDID-BLZ-DEV-DSC .

| | | |
| :--- | :--- | :--- |
|  <prev | [top](#top) |  next> |

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust#1.1.6 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust/history.html)|[License](license.md) 

