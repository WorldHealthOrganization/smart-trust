# WHO GDHCN Key Usage CodeSystem - DEV - WHO SMART Trust v1.1.6

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **WHO GDHCN Key Usage CodeSystem - DEV**

WHO SMART Trust, published by WHO. This guide is not an authorized publication; it is the continuous build for version 1.1.6 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/WorldHealthOrganization/smart-trust/tree/tng-additional-context-jsonld](https://github.com/WorldHealthOrganization/smart-trust/tree/tng-additional-context-jsonld) and changes regularly. See the [Directory of published versions](http://smart.who.int/trust/history.html)

*  [Narrative Content](#) 
*  [XML](CodeSystem-KeyUsage-DEV.xml.md) 
*  [JSON](CodeSystem-KeyUsage-DEV.json.md) 
*  [TTL](CodeSystem-KeyUsage-DEV.ttl.md) 

## CodeSystem: WHO GDHCN Key Usage CodeSystem - DEV (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/trust/CodeSystem/KeyUsage-DEV | *Version*:1.1.6 |
| Active as of 2025-10-07 | *Computable Name*:KeyUsage-DEV |

 
CodeSystem for GDHCN Key Usage that has usage codes for verification keys published to the Trust Network as defined by the[certificate governance](concepts_certificate_governance.md)for Development environment 

 This Code system is referenced in the content logical definition of the following value sets: 

* [KeyUsage-DEV](ValueSet-KeyUsage-DEV.md)

This case-insensitive code system `http://smart.who.int/trust/CodeSystem/KeyUsage-DEV` defines the following codes:

| | | |
| :--- | :--- | :--- |
|  [<prev](CodeSystem-KeyUsage.ttl.md) | [top](#top) |  [next>](CodeSystem-KeyUsage-DEV-testing.md) |

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust#1.1.6 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust/history.html)|[License](license.md) 

