# Publish HL7 FHIR business rules - TTL Representation - WHO SMART Trust v1.4.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Publish HL7 FHIR business rules**

## : Publish HL7 FHIR business rules - TTL Representation

| |
| :--- |
| Active as of 2026-01-12 |

[Raw ttl](Requirements-PublishBusinessRulesFHIR.ttl) | [Download](Requirements-PublishBusinessRulesFHIR.ttl)

