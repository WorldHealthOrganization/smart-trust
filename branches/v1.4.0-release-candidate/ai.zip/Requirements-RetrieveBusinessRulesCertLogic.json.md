# Retrieve Cert Logic compatible business rules - JSON Representation - WHO SMART Trust v1.4.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Retrieve Cert Logic compatible business rules**

## : Retrieve Cert Logic compatible business rules - JSON Representation

| |
| :--- |
| Active as of 2026-01-12 |

[Raw json](Requirements-RetrieveBusinessRulesCertLogic.json) | [Download](Requirements-RetrieveBusinessRulesCertLogic.json)

