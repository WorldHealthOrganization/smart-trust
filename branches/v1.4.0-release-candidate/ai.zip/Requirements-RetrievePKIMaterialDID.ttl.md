# Retrieve PKI material as DID - TTL Representation - WHO SMART Trust v1.4.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Retrieve PKI material as DID**

## : Retrieve PKI material as DID - TTL Representation

| |
| :--- |
| Active as of 2026-01-12 |

[Raw ttl](Requirements-RetrievePKIMaterialDID.ttl) | [Download](Requirements-RetrievePKIMaterialDID.ttl)

