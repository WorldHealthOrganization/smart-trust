# Trust Network Participant - XML Representation - WHO SMART Trust v1.4.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Trust Network Participant**

## : Trust Network Participant - XML Representation

| |
| :--- |
| Active as of 2026-01-12 |

[Raw xml](ActorDefinition-TrustNetworkParticipant.xml) | [Download](ActorDefinition-TrustNetworkParticipant.xml)

