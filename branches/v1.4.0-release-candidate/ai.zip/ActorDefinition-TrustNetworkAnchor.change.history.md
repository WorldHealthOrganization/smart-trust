#  - WHO SMART Trust v1.4.0

## : Trust Network Anchor - Change History

History of changes for TrustNetworkAnchor .

