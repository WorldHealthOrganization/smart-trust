# Receive PKI material as DID - TTL Representation - WHO SMART Trust v1.4.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Receive PKI material as DID**

## : Receive PKI material as DID - TTL Representation

| |
| :--- |
| Active as of 2026-01-12 |

[Raw ttl](Requirements-ReceivePKUMaterialDID.ttl) | [Download](Requirements-ReceivePKUMaterialDID.ttl)

