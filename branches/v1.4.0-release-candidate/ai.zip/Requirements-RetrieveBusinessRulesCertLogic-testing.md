# Retrieve Cert Logic compatible business rules - Testing - WHO SMART Trust v1.4.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Retrieve Cert Logic compatible business rules**

## Requirements: Retrieve Cert Logic compatible business rules - Testing (Experimental) 

| |
| :--- |
| Active as of 2026-01-12 |

### Test Plans

**No test plans are currently available for the Requirements.**

### Test Scripts

**No test scripts are currently available for the Requirements.**

