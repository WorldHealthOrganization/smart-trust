# Utilize a Verifiable Digital Health Certificate - TTL Representation - WHO SMART Trust v1.4.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Utilize a Verifiable Digital Health Certificate**

## : Utilize a Verifiable Digital Health Certificate - TTL Representation

| |
| :--- |
| Active as of 2026-01-12 |

[Raw ttl](Requirements-UtilizeVDHC.ttl) | [Download](Requirements-UtilizeVDHC.ttl)

