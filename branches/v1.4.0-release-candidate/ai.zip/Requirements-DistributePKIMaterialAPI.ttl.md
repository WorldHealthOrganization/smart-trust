# Distribute PKI material via API - TTL Representation - WHO SMART Trust v1.4.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Distribute PKI material via API**

## : Distribute PKI material via API - TTL Representation

| |
| :--- |
| Active as of 2026-01-12 |

[Raw ttl](Requirements-DistributePKIMaterialAPI.ttl) | [Download](Requirements-DistributePKIMaterialAPI.ttl)

