# Trust Network Participant - JSON Representation - WHO SMART Trust v1.4.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Trust Network Participant**

## : Trust Network Participant - JSON Representation

| |
| :--- |
| Active as of 2026-01-12 |

[Raw json](ActorDefinition-TrustNetworkParticipant.json) | [Download](ActorDefinition-TrustNetworkParticipant.json)

