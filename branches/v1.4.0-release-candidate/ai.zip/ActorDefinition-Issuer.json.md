# Issuer - JSON Representation - WHO SMART Trust v1.4.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Issuer**

## : Issuer - JSON Representation

| |
| :--- |
| Active as of 2026-01-12 |

[Raw json](ActorDefinition-Issuer.json) | [Download](ActorDefinition-Issuer.json)

