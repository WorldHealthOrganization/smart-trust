# Publish PKI material - XML Representation - WHO SMART Trust v1.4.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Publish PKI material**

## : Publish PKI material - XML Representation

| |
| :--- |
| Active as of 2026-01-12 |

[Raw xml](Requirements-PublishPKIMaterial.xml) | [Download](Requirements-PublishPKIMaterial.xml)

