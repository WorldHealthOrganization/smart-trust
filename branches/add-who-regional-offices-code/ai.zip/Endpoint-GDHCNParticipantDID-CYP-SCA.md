# GDHCNParticipantDID-CYP-SCA - WHO SMART Trust v1.1.6

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-CYP-SCA**

## Endpoint: GDHCNParticipantDID-CYP-SCA

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: Cyprus Trustlist (DID v2) - Certificate Signing Authority did:web:tng-cdn.who.int:v2:trustlist:-:CYP:SCA resolvable at https://tng-cdn.who.int/v2/trustlist/-/CYP/SCA/did.json

**managingOrganization**: [Organization Cyprus](Organization-GDHCNParticipant-CYP.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:CYP:SCA



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-CYP-SCA",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Cyprus Trustlist (DID v2) - Certificate Signing Authority\ndid:web:tng-cdn.who.int:v2:trustlist:-:CYP:SCA\nresolvable at https://tng-cdn.who.int/v2/trustlist/-/CYP/SCA/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-CYP"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:CYP:SCA"
}

```
