# GDHCNParticipantDID-PAN-DEV-All - WHO SMART Trust v1.7.5

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-PAN-DEV-All**

## Endpoint: GDHCNParticipantDID-PAN-DEV-All

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Panama Trustlist (DID v2) - DEV - All keys did:web:tng-cdn.who.int:v2:trustlist:-:PAN resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/PAN/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:PAN

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:PAN |
| Connection Type: |  |
| Managed By: | [Panama (Government)](Organization-GDHCNParticipant-PAN-DEV.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-PAN-DEV-All",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Panama Trustlist (DID v2) - DEV - All keys\ndid:web:tng-cdn.who.int:v2:trustlist:-:PAN\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/PAN/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-PAN-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:PAN"
}

```
