# GDHCNParticipantDID-IOM-DEV-All - WHO SMART Trust v1.8.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-IOM-DEV-All**

## Endpoint: GDHCNParticipantDID-IOM-DEV-All

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: TEST Trustlist (DID v2) - DEV - All keys did:web:tng-cdn.who.int:v2:trustlist:-:IOM resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/IOM/did.json

**managingOrganization**: [Organization TEST](Organization-GDHCNParticipant-IOM-DEV.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:IOM



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-IOM-DEV-All",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "TEST Trustlist (DID v2) - DEV - All keys\ndid:web:tng-cdn.who.int:v2:trustlist:-:IOM\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/IOM/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-IOM-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:IOM"
}

```
