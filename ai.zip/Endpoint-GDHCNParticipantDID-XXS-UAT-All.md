# GDHCNParticipantDID-XXS-UAT-All - WHO SMART Trust v1.7.5

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-XXS-UAT-All**

## Endpoint: GDHCNParticipantDID-XXS-UAT-All

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Test Locality Trustlist (DID v2) - UAT - All keys did:web:tng-cdn.who.int:v2:trustlist:-:XXS resolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/XXS/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:XXS

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:XXS |
| Connection Type: |  |
| Managed By: | [Test Locality (Government)](Organization-GDHCNParticipant-XXS-UAT.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-XXS-UAT-All",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Test Locality Trustlist (DID v2) - UAT - All keys\ndid:web:tng-cdn.who.int:v2:trustlist:-:XXS\nresolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/XXS/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-XXS-UAT"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:XXS"
}

```
