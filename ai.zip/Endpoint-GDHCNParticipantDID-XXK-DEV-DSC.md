# GDHCNParticipantDID-XXK-DEV-DSC - WHO SMART Trust v1.7.5

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-XXK-DEV-DSC**

## Endpoint: GDHCNParticipantDID-XXK-DEV-DSC

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Rengo Trustlist (DID v2) - DEV - Document Signing Certificates did:web:tng-cdn.who.int:v2:trustlist:-:XXK:DSC resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XXK/DSC/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:XXK:DSC

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:XXK:DSC |
| Connection Type: |  |
| Managed By: | [Rengo (Government)](Organization-GDHCNParticipant-XXK-DEV.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-XXK-DEV-DSC",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Rengo Trustlist (DID v2) - DEV - Document Signing Certificates\ndid:web:tng-cdn.who.int:v2:trustlist:-:XXK:DSC\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XXK/DSC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-XXK-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:XXK:DSC"
}

```
