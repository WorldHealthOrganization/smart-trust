# GDHCNParticipantDID-XXD-UAT-All - WHO SMART Trust v1.7.5

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-XXD-UAT-All**

## Endpoint: GDHCNParticipantDID-XXD-UAT-All

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

UAT Participant XXD Trustlist (DID v2) - UAT - All keys did:web:tng-cdn.who.int:v2:trustlist:-:XXD resolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/XXD/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:XXD

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:XXD |
| Connection Type: |  |
| Managed By: | [UAT Participant XXD (Government)](Organization-GDHCNParticipant-XXD-UAT.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-XXD-UAT-All",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "UAT Participant XXD Trustlist (DID v2) - UAT - All keys\ndid:web:tng-cdn.who.int:v2:trustlist:-:XXD\nresolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/XXD/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-XXD-UAT"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:XXD"
}

```
