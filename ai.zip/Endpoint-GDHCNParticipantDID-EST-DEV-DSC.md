# GDHCNParticipantDID-EST-DEV-DSC - WHO SMART Trust v1.7.5

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-EST-DEV-DSC**

## Endpoint: GDHCNParticipantDID-EST-DEV-DSC

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Estonia Trustlist (DID v2) - DEV - Document Signing Certificates did:web:tng-cdn.who.int:v2:trustlist:-:EST:DSC resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/EST/DSC/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:EST:DSC

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:EST:DSC |
| Connection Type: |  |
| Managed By: | [Estonia (Government)](Organization-GDHCNParticipant-EST-DEV.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-EST-DEV-DSC",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Estonia Trustlist (DID v2) - DEV - Document Signing Certificates\ndid:web:tng-cdn.who.int:v2:trustlist:-:EST:DSC\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/EST/DSC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-EST-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:EST:DSC"
}

```
