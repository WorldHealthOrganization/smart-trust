# GDHCNParticipantDID-AND-DEV-All - WHO SMART Trust v1.7.5

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-AND-DEV-All**

## Endpoint: GDHCNParticipantDID-AND-DEV-All

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Andorra Trustlist (DID v2) - DEV - All keys did:web:tng-cdn.who.int:v2:trustlist:-:AND resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/AND/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:AND

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:AND |
| Connection Type: |  |
| Managed By: | [Andorra (Government)](Organization-GDHCNParticipant-AND-DEV.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-AND-DEV-All",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Andorra Trustlist (DID v2) - DEV - All keys\ndid:web:tng-cdn.who.int:v2:trustlist:-:AND\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/AND/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-AND-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:AND"
}

```
