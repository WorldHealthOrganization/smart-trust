# GDHCNParticipantDID-SVK-All - WHO SMART Trust v1.7.5

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-SVK-All**

## Endpoint: GDHCNParticipantDID-SVK-All

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Slovakia Trustlist (DID v2) - All keys did:web:tng-cdn.who.int:v2:trustlist:-:SVK resolvable at https://tng-cdn.who.int/v2/trustlist/-/SVK/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:SVK

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:SVK |
| Connection Type: |  |
| Managed By: | [Slovakia (Government)](Organization-GDHCNParticipant-SVK.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-SVK-All",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Slovakia Trustlist (DID v2) - All keys\ndid:web:tng-cdn.who.int:v2:trustlist:-:SVK\nresolvable at https://tng-cdn.who.int/v2/trustlist/-/SVK/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-SVK"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:SVK"
}

```
