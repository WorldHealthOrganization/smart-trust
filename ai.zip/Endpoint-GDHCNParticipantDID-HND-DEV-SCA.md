# GDHCNParticipantDID-HND-DEV-SCA - WHO SMART Trust v1.1.6

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-HND-DEV-SCA**

## Endpoint: GDHCNParticipantDID-HND-DEV-SCA

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: Honduras Trustlist (DID v2) - DEV - Certificate Signing Authority did:web:tng-cdn.who.int:v2:trustlist:-:HND:SCA resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/HND/SCA/did.json

**managingOrganization**: [Organization Honduras](Organization-GDHCNParticipant-HND-DEV.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:HND:SCA



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-HND-DEV-SCA",
  "meta" : {
    "profile" : [
      "https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"
    ]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Honduras Trustlist (DID v2) - DEV - Certificate Signing Authority\ndid:web:tng-cdn.who.int:v2:trustlist:-:HND:SCA\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/HND/SCA/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-HND-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:HND:SCA"
}

```
