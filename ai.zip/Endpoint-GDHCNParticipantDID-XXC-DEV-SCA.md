# GDHCNParticipantDID-XXC-DEV-SCA - WHO SMART Trust v1.7.5

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-XXC-DEV-SCA**

## Endpoint: GDHCNParticipantDID-XXC-DEV-SCA

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

TEST Trustlist (DID v2) - DEV - Certificate Signing Authority did:web:tng-cdn.who.int:v2:trustlist:-:XXC:SCA resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XXC/SCA/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:XXC:SCA

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:XXC:SCA |
| Connection Type: |  |
| Managed By: | [TEST (Government)](Organization-GDHCNParticipant-XXC-DEV.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-XXC-DEV-SCA",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "TEST Trustlist (DID v2) - DEV - Certificate Signing Authority\ndid:web:tng-cdn.who.int:v2:trustlist:-:XXC:SCA\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XXC/SCA/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-XXC-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:XXC:SCA"
}

```
