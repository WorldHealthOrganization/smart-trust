# GDHCNParticipantDID-CZE-All - WHO SMART Trust v1.7.5

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-CZE-All**

## Endpoint: GDHCNParticipantDID-CZE-All

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Czechia Trustlist (DID v2) - All keys did:web:tng-cdn.who.int:v2:trustlist:-:CZE resolvable at https://tng-cdn.who.int/v2/trustlist/-/CZE/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:CZE

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:CZE |
| Connection Type: |  |
| Managed By: | [Czechia (Government)](Organization-GDHCNParticipant-CZE.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-CZE-All",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Czechia Trustlist (DID v2) - All keys\ndid:web:tng-cdn.who.int:v2:trustlist:-:CZE\nresolvable at https://tng-cdn.who.int/v2/trustlist/-/CZE/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-CZE"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:CZE"
}

```
