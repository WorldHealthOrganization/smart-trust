# GDHCNParticipantDID-BEL-All - WHO SMART Trust v1.7.5

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-BEL-All**

## Endpoint: GDHCNParticipantDID-BEL-All

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Belgium Trustlist (DID v2) - All keys did:web:tng-cdn.who.int:v2:trustlist:-:BEL resolvable at https://tng-cdn.who.int/v2/trustlist/-/BEL/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:BEL

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:BEL |
| Connection Type: |  |
| Managed By: | [Belgium (Government)](Organization-GDHCNParticipant-BEL.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-BEL-All",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Belgium Trustlist (DID v2) - All keys\ndid:web:tng-cdn.who.int:v2:trustlist:-:BEL\nresolvable at https://tng-cdn.who.int/v2/trustlist/-/BEL/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-BEL"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:BEL"
}

```
