# GDHCNParticipantDID-SVN-UAT-DSC - WHO SMART Trust v1.7.5

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-SVN-UAT-DSC**

## Endpoint: GDHCNParticipantDID-SVN-UAT-DSC

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Slovenia Trustlist (DID v2) - UAT - Document Signing Certificates did:web:tng-cdn.who.int:v2:trustlist:-:SVN:DSC resolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/SVN/DSC/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:SVN:DSC

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:SVN:DSC |
| Connection Type: |  |
| Managed By: | [Slovenia (Government)](Organization-GDHCNParticipant-SVN-UAT.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-SVN-UAT-DSC",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Slovenia Trustlist (DID v2) - UAT - Document Signing Certificates\ndid:web:tng-cdn.who.int:v2:trustlist:-:SVN:DSC\nresolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/SVN/DSC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-SVN-UAT"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:SVN:DSC"
}

```
