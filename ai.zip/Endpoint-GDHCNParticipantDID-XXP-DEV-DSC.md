# GDHCNParticipantDID-XXP-DEV-DSC - WHO SMART Trust v1.7.5

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-XXP-DEV-DSC**

## Endpoint: GDHCNParticipantDID-XXP-DEV-DSC

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Geneva Trustlist (DID v2) - DEV - Document Signing Certificates did:web:tng-cdn.who.int:v2:trustlist:-:XXP:DSC resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XXP/DSC/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:XXP:DSC

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:XXP:DSC |
| Connection Type: |  |
| Managed By: | [Geneva (Government)](Organization-GDHCNParticipant-XXP-DEV.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-XXP-DEV-DSC",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Geneva Trustlist (DID v2) - DEV - Document Signing Certificates\ndid:web:tng-cdn.who.int:v2:trustlist:-:XXP:DSC\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XXP/DSC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-XXP-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:XXP:DSC"
}

```
