# Trust Network Participant - WHO SMART Trust v1.7.5

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Trust Network Participant**

## ActorDefinition: Trust Network Participant (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/trust/ActorDefinition/TrustNetworkParticipant | *Version*:1.7.5 |
| Active as of 2026-10-09 | *Computable Name*:Trust Network Participant |

 
Trust Network Participant which publishes and or receives PKI-material within a Trust Network 

* Publisher: Contact Email
  * No publisher has been registered.: No contact email has been registered.
* Publisher: Jurisdiction
  * No publisher has been registered.: 
* Publisher: Requirements
  * No publisher has been registered.: This actor fulfills the following requirements:



## Resource Content

```json
{
  "resourceType" : "ActorDefinition",
  "id" : "TrustNetworkParticipant",
  "meta" : {
    "profile" : ["http://smart.who.int/base/StructureDefinition/SGActor"]
  },
  "url" : "http://smart.who.int/trust/ActorDefinition/TrustNetworkParticipant",
  "version" : "1.7.5",
  "name" : "Trust Network Participant",
  "title" : "Trust Network Participant",
  "status" : "active",
  "experimental" : true,
  "date" : "2026-10-09T13:18:08+00:00",
  "publisher" : "WHO",
  "contact" : [{
    "name" : "WHO",
    "telecom" : [{
      "system" : "url",
      "value" : "http://who.int"
    }]
  }],
  "description" : "Trust Network Participant which publishes and or receives PKI-material within a Trust Network",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "http://unstats.un.org/unsd/methods/m49/m49.htm",
      "code" : "001"
    }]
  }],
  "type" : "system"
}

```
