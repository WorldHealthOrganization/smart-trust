# GDHCNParticipantDID-IDN-DEV-All - WHO SMART Trust v1.7.5

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-IDN-DEV-All**

## Endpoint: GDHCNParticipantDID-IDN-DEV-All

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Indonesia Trustlist (DID v2) - DEV - All keys did:web:tng-cdn.who.int:v2:trustlist:-:IDN resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/IDN/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:IDN

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:IDN |
| Connection Type: |  |
| Managed By: | [Indonesia (Government)](Organization-GDHCNParticipant-IDN-DEV.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-IDN-DEV-All",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Indonesia Trustlist (DID v2) - DEV - All keys\ndid:web:tng-cdn.who.int:v2:trustlist:-:IDN\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/IDN/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-IDN-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:IDN"
}

```
