# GDHCNParticipantDID-ECU-DEV-DSC - WHO SMART Trust v1.7.5

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-ECU-DEV-DSC**

## Endpoint: GDHCNParticipantDID-ECU-DEV-DSC

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Ecuador Trustlist (DID v2) - DEV - Document Signing Certificates did:web:tng-cdn.who.int:v2:trustlist:-:ECU:DSC resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/ECU/DSC/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:ECU:DSC

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:ECU:DSC |
| Connection Type: |  |
| Managed By: | [Ecuador (Government)](Organization-GDHCNParticipant-ECU-DEV.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-ECU-DEV-DSC",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Ecuador Trustlist (DID v2) - DEV - Document Signing Certificates\ndid:web:tng-cdn.who.int:v2:trustlist:-:ECU:DSC\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/ECU/DSC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-ECU-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:ECU:DSC"
}

```
