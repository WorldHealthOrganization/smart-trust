# GDHCNParticipantDID-SMR-DEV-All - WHO SMART Trust v1.7.5

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-SMR-DEV-All**

## Endpoint: GDHCNParticipantDID-SMR-DEV-All

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

San Marino Trustlist (DID v2) - DEV - All keys did:web:tng-cdn.who.int:v2:trustlist:-:SMR resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/SMR/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:SMR

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:SMR |
| Connection Type: |  |
| Managed By: | [San Marino (Government)](Organization-GDHCNParticipant-SMR-DEV.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-SMR-DEV-All",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "San Marino Trustlist (DID v2) - DEV - All keys\ndid:web:tng-cdn.who.int:v2:trustlist:-:SMR\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/SMR/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-SMR-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:SMR"
}

```
