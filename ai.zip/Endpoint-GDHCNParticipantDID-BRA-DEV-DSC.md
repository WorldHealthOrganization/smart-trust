# GDHCNParticipantDID-BRA-DEV-DSC - WHO SMART Trust v1.7.5

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-BRA-DEV-DSC**

## Endpoint: GDHCNParticipantDID-BRA-DEV-DSC

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Brazil Trustlist (DID v2) - DEV - Document Signing Certificates did:web:tng-cdn.who.int:v2:trustlist:-:BRA:DSC resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/BRA/DSC/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:BRA:DSC

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:BRA:DSC |
| Connection Type: |  |
| Managed By: | [Brazil (Government)](Organization-GDHCNParticipant-BRA-DEV.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-BRA-DEV-DSC",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Brazil Trustlist (DID v2) - DEV - Document Signing Certificates\ndid:web:tng-cdn.who.int:v2:trustlist:-:BRA:DSC\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/BRA/DSC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-BRA-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:BRA:DSC"
}

```
