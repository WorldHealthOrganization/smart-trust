# GDHCNParticipantDID-XXF-DEV-DSC - WHO SMART Trust v1.8.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-XXF-DEV-DSC**

## Endpoint: GDHCNParticipantDID-XXF-DEV-DSC

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: Test Locality XF Trustlist (DID v2) - DEV - Document Signing Certificates did:web:tng-cdn.who.int:v2:trustlist:-:XXF:DSC resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XXF/DSC/did.json

**managingOrganization**: [Organization Test Locality XF](Organization-GDHCNParticipant-XXF-DEV.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:XXF:DSC



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-XXF-DEV-DSC",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Test Locality XF Trustlist (DID v2) - DEV - Document Signing Certificates\ndid:web:tng-cdn.who.int:v2:trustlist:-:XXF:DSC\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XXF/DSC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-XXF-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:XXF:DSC"
}

```
