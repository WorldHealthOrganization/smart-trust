# GDHCNParticipantDID-CZE-UAT-SCA - WHO SMART Trust v1.7.5

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-CZE-UAT-SCA**

## Endpoint: GDHCNParticipantDID-CZE-UAT-SCA

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Czechia Trustlist (DID v2) - UAT - Certificate Signing Authority did:web:tng-cdn.who.int:v2:trustlist:-:CZE:SCA resolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/CZE/SCA/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:CZE:SCA

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:CZE:SCA |
| Connection Type: |  |
| Managed By: | [Czechia (Government)](Organization-GDHCNParticipant-CZE-UAT.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-CZE-UAT-SCA",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Czechia Trustlist (DID v2) - UAT - Certificate Signing Authority\ndid:web:tng-cdn.who.int:v2:trustlist:-:CZE:SCA\nresolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/CZE/SCA/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-CZE-UAT"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:CZE:SCA"
}

```
