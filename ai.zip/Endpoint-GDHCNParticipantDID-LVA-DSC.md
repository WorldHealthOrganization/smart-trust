# GDHCNParticipantDID-LVA-DSC - WHO SMART Trust v1.7.5

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-LVA-DSC**

## Endpoint: GDHCNParticipantDID-LVA-DSC

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Latvia Trustlist (DID v2) - Document Signing Certificates did:web:tng-cdn.who.int:v2:trustlist:-:LVA:DSC resolvable at https://tng-cdn.who.int/v2/trustlist/-/LVA/DSC/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:LVA:DSC

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:LVA:DSC |
| Connection Type: |  |
| Managed By: | [Latvia (Government)](Organization-GDHCNParticipant-LVA.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-LVA-DSC",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Latvia Trustlist (DID v2) - Document Signing Certificates\ndid:web:tng-cdn.who.int:v2:trustlist:-:LVA:DSC\nresolvable at https://tng-cdn.who.int/v2/trustlist/-/LVA/DSC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-LVA"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:LVA:DSC"
}

```
