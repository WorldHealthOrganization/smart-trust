# GDHCNParticipantDID-CRI-DEV-DSC - WHO SMART Trust v1.7.5

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-CRI-DEV-DSC**

## Endpoint: GDHCNParticipantDID-CRI-DEV-DSC

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Costa Rica Trustlist (DID v2) - DEV - Document Signing Certificates did:web:tng-cdn.who.int:v2:trustlist:-:CRI:DSC resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/CRI/DSC/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:CRI:DSC

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:CRI:DSC |
| Connection Type: |  |
| Managed By: | [Costa Rica (Government)](Organization-GDHCNParticipant-CRI-DEV.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-CRI-DEV-DSC",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Costa Rica Trustlist (DID v2) - DEV - Document Signing Certificates\ndid:web:tng-cdn.who.int:v2:trustlist:-:CRI:DSC\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/CRI/DSC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-CRI-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:CRI:DSC"
}

```
