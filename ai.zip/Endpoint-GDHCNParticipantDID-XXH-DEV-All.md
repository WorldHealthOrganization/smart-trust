# GDHCNParticipantDID-XXH-DEV-All - WHO SMART Trust v1.7.5

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-XXH-DEV-All**

## Endpoint: GDHCNParticipantDID-XXH-DEV-All

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Geneva Trustlist (DID v2) - DEV - All keys did:web:tng-cdn.who.int:v2:trustlist:-:XXH resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XXH/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:XXH

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:XXH |
| Connection Type: |  |
| Managed By: | [Geneva (Government)](Organization-GDHCNParticipant-XXH-DEV.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-XXH-DEV-All",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Geneva Trustlist (DID v2) - DEV - All keys\ndid:web:tng-cdn.who.int:v2:trustlist:-:XXH\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XXH/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-XXH-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:XXH"
}

```
