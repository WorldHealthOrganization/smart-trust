# GDHCNParticipantDID-CYP-All - WHO SMART Trust v1.8.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-CYP-All**

## Endpoint: GDHCNParticipantDID-CYP-All

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: Cyprus Trustlist (DID v2) - All keys did:web:tng-cdn.who.int:v2:trustlist:-:CYP resolvable at https://tng-cdn.who.int/v2/trustlist/-/CYP/did.json

**managingOrganization**: [Organization Cyprus](Organization-GDHCNParticipant-CYP.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:CYP



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-CYP-All",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Cyprus Trustlist (DID v2) - All keys\ndid:web:tng-cdn.who.int:v2:trustlist:-:CYP\nresolvable at https://tng-cdn.who.int/v2/trustlist/-/CYP/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-CYP"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:CYP"
}

```
