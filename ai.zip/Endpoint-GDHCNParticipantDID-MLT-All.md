# GDHCNParticipantDID-MLT-All - WHO SMART Trust v1.7.5

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-MLT-All**

## Endpoint: GDHCNParticipantDID-MLT-All

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Malta Trustlist (DID v2) - All keys did:web:tng-cdn.who.int:v2:trustlist:-:MLT resolvable at https://tng-cdn.who.int/v2/trustlist/-/MLT/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:MLT

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:MLT |
| Connection Type: |  |
| Managed By: | [Malta (Government)](Organization-GDHCNParticipant-MLT.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-MLT-All",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Malta Trustlist (DID v2) - All keys\ndid:web:tng-cdn.who.int:v2:trustlist:-:MLT\nresolvable at https://tng-cdn.who.int/v2/trustlist/-/MLT/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-MLT"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:MLT"
}

```
