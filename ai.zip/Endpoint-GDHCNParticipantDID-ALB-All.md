# GDHCNParticipantDID-ALB-All - WHO SMART Trust v1.7.5

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-ALB-All**

## Endpoint: GDHCNParticipantDID-ALB-All

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Albania Trustlist (DID v2) - All keys did:web:tng-cdn.who.int:v2:trustlist:-:ALB resolvable at https://tng-cdn.who.int/v2/trustlist/-/ALB/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:ALB

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:ALB |
| Connection Type: |  |
| Managed By: | [Albania (Government)](Organization-GDHCNParticipant-ALB.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-ALB-All",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Albania Trustlist (DID v2) - All keys\ndid:web:tng-cdn.who.int:v2:trustlist:-:ALB\nresolvable at https://tng-cdn.who.int/v2/trustlist/-/ALB/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-ALB"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:ALB"
}

```
