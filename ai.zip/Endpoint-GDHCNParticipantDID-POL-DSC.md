# GDHCNParticipantDID-POL-DSC - WHO SMART Trust v1.7.5

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-POL-DSC**

## Endpoint: GDHCNParticipantDID-POL-DSC

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Poland Trustlist (DID v2) - Document Signing Certificates did:web:tng-cdn.who.int:v2:trustlist:-:POL:DSC resolvable at https://tng-cdn.who.int/v2/trustlist/-/POL/DSC/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:POL:DSC

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:POL:DSC |
| Connection Type: |  |
| Managed By: | [Poland (Government)](Organization-GDHCNParticipant-POL.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-POL-DSC",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Poland Trustlist (DID v2) - Document Signing Certificates\ndid:web:tng-cdn.who.int:v2:trustlist:-:POL:DSC\nresolvable at https://tng-cdn.who.int/v2/trustlist/-/POL/DSC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-POL"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:POL:DSC"
}

```
