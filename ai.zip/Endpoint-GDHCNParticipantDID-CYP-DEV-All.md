# GDHCNParticipantDID-CYP-DEV-All - WHO SMART Trust v1.7.5

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-CYP-DEV-All**

## Endpoint: GDHCNParticipantDID-CYP-DEV-All

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

Cyprus Trustlist (DID v2) - DEV - All keys did:web:tng-cdn.who.int:v2:trustlist:-:CYP resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/CYP/did.json (): did:web:tng-cdn.who.int:v2:trustlist:-:CYP

-------

| | |
| :--- | :--- |
| Status: | Active |
| Address: | did:web:tng-cdn.who.int:v2:trustlist:-:CYP |
| Connection Type: |  |
| Managed By: | [Cyprus (Government)](Organization-GDHCNParticipant-CYP-DEV.md) |



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-CYP-DEV-All",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Cyprus Trustlist (DID v2) - DEV - All keys\ndid:web:tng-cdn.who.int:v2:trustlist:-:CYP\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/CYP/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-CYP-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:CYP"
}

```
