# GDHCNParticipantDID-FRA-UAT-All - WHO SMART Trust v1.8.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-FRA-UAT-All**

## Endpoint: GDHCNParticipantDID-FRA-UAT-All

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: France Trustlist (DID v2) - UAT - All keys did:web:tng-cdn.who.int:v2:trustlist:-:FRA resolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/FRA/did.json

**managingOrganization**: [Organization France](Organization-GDHCNParticipant-FRA-UAT.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:FRA



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-FRA-UAT-All",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "France Trustlist (DID v2) - UAT - All keys\ndid:web:tng-cdn.who.int:v2:trustlist:-:FRA\nresolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/FRA/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-FRA-UAT"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:FRA"
}

```
