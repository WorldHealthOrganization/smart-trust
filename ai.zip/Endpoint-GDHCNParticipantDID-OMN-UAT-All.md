# GDHCNParticipantDID-OMN-UAT-All - WHO SMART Trust v1.8.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-OMN-UAT-All**

## Endpoint: GDHCNParticipantDID-OMN-UAT-All

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: Oman Trustlist (DID v2) - UAT - All keys did:web:tng-cdn.who.int:v2:trustlist:-:OMN resolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/OMN/did.json

**managingOrganization**: [Organization Oman](Organization-GDHCNParticipant-OMN-UAT.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:OMN



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-OMN-UAT-All",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Oman Trustlist (DID v2) - UAT - All keys\ndid:web:tng-cdn.who.int:v2:trustlist:-:OMN\nresolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/OMN/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-OMN-UAT"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:OMN"
}

```
