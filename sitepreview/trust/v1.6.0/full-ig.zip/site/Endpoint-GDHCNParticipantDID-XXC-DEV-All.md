# GDHCNParticipantDID-XXC-DEV-All - WHO SMART Trust v1.6.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-XXC-DEV-All**

## Endpoint: GDHCNParticipantDID-XXC-DEV-All

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: DEV Participant XXC Trustlist (DID v2) - DEV - All keys did:web:tng-cdn.who.int:v2:trustlist:-:XXC resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XXC/did.json

**managingOrganization**: [Organization DEV Participant XXC](Organization-GDHCNParticipant-XXC-DEV.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:XXC



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-XXC-DEV-All",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "DEV Participant XXC Trustlist (DID v2) - DEV - All keys\ndid:web:tng-cdn.who.int:v2:trustlist:-:XXC\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XXC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-XXC-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:XXC"
}

```
