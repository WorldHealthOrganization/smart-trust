# GDHCNParticipantDID-LTU-SCA - WHO SMART Trust v1.5.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-LTU-SCA**

## Endpoint: GDHCNParticipantDID-LTU-SCA

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: Lithuania Trustlist (DID v2) - Certificate Signing Authority did:web:tng-cdn.who.int:v2:trustlist:-:LTU:SCA resolvable at https://tng-cdn.who.int/v2/trustlist/-/LTU/SCA/did.json

**managingOrganization**: [Organization Lithuania](Organization-GDHCNParticipant-LTU.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:LTU:SCA



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-LTU-SCA",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Lithuania Trustlist (DID v2) - Certificate Signing Authority\ndid:web:tng-cdn.who.int:v2:trustlist:-:LTU:SCA\nresolvable at https://tng-cdn.who.int/v2/trustlist/-/LTU/SCA/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-LTU"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:LTU:SCA"
}

```
