# GDHCNParticipantDID-XXB-DEV-DSC - WHO SMART Trust v1.7.2

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-XXB-DEV-DSC**

## Endpoint: GDHCNParticipantDID-XXB-DEV-DSC

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: TEST Trustlist (DID v2) - DEV - Document Signing Certificates did:web:tng-cdn.who.int:v2:trustlist:-:XXB:DSC resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XXB/DSC/did.json

**managingOrganization**: [Organization TEST](Organization-GDHCNParticipant-XXB-DEV.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:XXB:DSC



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-XXB-DEV-DSC",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "TEST Trustlist (DID v2) - DEV - Document Signing Certificates\ndid:web:tng-cdn.who.int:v2:trustlist:-:XXB:DSC\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XXB/DSC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-XXB-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:XXB:DSC"
}

```
