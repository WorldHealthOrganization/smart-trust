# GDHCNParticipantDID-IOM-DEV-SCA - WHO SMART Trust v1.7.2

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-IOM-DEV-SCA**

## Endpoint: GDHCNParticipantDID-IOM-DEV-SCA

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: TEST Trustlist (DID v2) - DEV - Certificate Signing Authority did:web:tng-cdn.who.int:v2:trustlist:-:IOM:SCA resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/IOM/SCA/did.json

**managingOrganization**: [Organization TEST](Organization-GDHCNParticipant-IOM-DEV.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:IOM:SCA



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-IOM-DEV-SCA",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "TEST Trustlist (DID v2) - DEV - Certificate Signing Authority\ndid:web:tng-cdn.who.int:v2:trustlist:-:IOM:SCA\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/IOM/SCA/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-IOM-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:IOM:SCA"
}

```
