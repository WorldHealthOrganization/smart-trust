# GDHCNParticipantDID-BEN-All - WHO SMART Trust v1.7.2

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-BEN-All**

## Endpoint: GDHCNParticipantDID-BEN-All

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: Benin Trustlist (DID v2) - All keys did:web:tng-cdn.who.int:v2:trustlist:-:BEN resolvable at https://tng-cdn.who.int/v2/trustlist/-/BEN/did.json

**managingOrganization**: [Organization Benin](Organization-GDHCNParticipant-BEN.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:BEN



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-BEN-All",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Benin Trustlist (DID v2) - All keys\ndid:web:tng-cdn.who.int:v2:trustlist:-:BEN\nresolvable at https://tng-cdn.who.int/v2/trustlist/-/BEN/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-BEN"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:BEN"
}

```
