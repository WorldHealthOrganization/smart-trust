# GDHCNParticipantDID-SVK-UAT-DSC - WHO SMART Trust v1.7.2

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-SVK-UAT-DSC**

## Endpoint: GDHCNParticipantDID-SVK-UAT-DSC

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: Slovakia Trustlist (DID v2) - UAT - Document Signing Certificates did:web:tng-cdn.who.int:v2:trustlist:-:SVK:DSC resolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/SVK/DSC/did.json

**managingOrganization**: [Organization Slovakia](Organization-GDHCNParticipant-SVK-UAT.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:SVK:DSC



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-SVK-UAT-DSC",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Slovakia Trustlist (DID v2) - UAT - Document Signing Certificates\ndid:web:tng-cdn.who.int:v2:trustlist:-:SVK:DSC\nresolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/SVK/DSC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-SVK-UAT"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:SVK:DSC"
}

```
