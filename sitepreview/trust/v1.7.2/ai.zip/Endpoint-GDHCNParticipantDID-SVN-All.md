# GDHCNParticipantDID-SVN-All - WHO SMART Trust v1.7.2

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-SVN-All**

## Endpoint: GDHCNParticipantDID-SVN-All

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: Slovenia Trustlist (DID v2) - All keys did:web:tng-cdn.who.int:v2:trustlist:-:SVN resolvable at https://tng-cdn.who.int/v2/trustlist/-/SVN/did.json

**managingOrganization**: [Organization Slovenia](Organization-GDHCNParticipant-SVN.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:SVN



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-SVN-All",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Slovenia Trustlist (DID v2) - All keys\ndid:web:tng-cdn.who.int:v2:trustlist:-:SVN\nresolvable at https://tng-cdn.who.int/v2/trustlist/-/SVN/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-SVN"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:SVN"
}

```
