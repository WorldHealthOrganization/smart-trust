# GDHCNParticipantDID-XXA-DEV-SCA - WHO SMART Trust v1.7.2

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-XXA-DEV-SCA**

## Endpoint: GDHCNParticipantDID-XXA-DEV-SCA

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: Geneva Trustlist (DID v2) - DEV - Certificate Signing Authority did:web:tng-cdn.who.int:v2:trustlist:-:XXA:SCA resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XXA/SCA/did.json

**managingOrganization**: [Organization Geneva](Organization-GDHCNParticipant-XXA-DEV.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:XXA:SCA



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-XXA-DEV-SCA",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Geneva Trustlist (DID v2) - DEV - Certificate Signing Authority\ndid:web:tng-cdn.who.int:v2:trustlist:-:XXA:SCA\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XXA/SCA/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-XXA-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:XXA:SCA"
}

```
