# GDHCNParticipantDID-SMR-All - WHO SMART Trust v1.7.2

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-SMR-All**

## Endpoint: GDHCNParticipantDID-SMR-All

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: San Marino Trustlist (DID v2) - All keys did:web:tng-cdn.who.int:v2:trustlist:-:SMR resolvable at https://tng-cdn.who.int/v2/trustlist/-/SMR/did.json

**managingOrganization**: [Organization San Marino](Organization-GDHCNParticipant-SMR.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:SMR



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-SMR-All",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "San Marino Trustlist (DID v2) - All keys\ndid:web:tng-cdn.who.int:v2:trustlist:-:SMR\nresolvable at https://tng-cdn.who.int/v2/trustlist/-/SMR/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-SMR"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:SMR"
}

```
