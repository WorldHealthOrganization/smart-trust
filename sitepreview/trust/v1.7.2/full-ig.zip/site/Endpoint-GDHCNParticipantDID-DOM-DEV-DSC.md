# GDHCNParticipantDID-DOM-DEV-DSC - WHO SMART Trust v1.7.2

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-DOM-DEV-DSC**

## Endpoint: GDHCNParticipantDID-DOM-DEV-DSC

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: Dominican Republic Trustlist (DID v2) - DEV - Document Signing Certificates did:web:tng-cdn.who.int:v2:trustlist:-:DOM:DSC resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/DOM/DSC/did.json

**managingOrganization**: [Organization Dominican Republic](Organization-GDHCNParticipant-DOM-DEV.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:DOM:DSC



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-DOM-DEV-DSC",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Dominican Republic Trustlist (DID v2) - DEV - Document Signing Certificates\ndid:web:tng-cdn.who.int:v2:trustlist:-:DOM:DSC\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/DOM/DSC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-DOM-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:DOM:DSC"
}

```
