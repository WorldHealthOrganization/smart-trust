# GDHCNParticipantDID-XXV-DEV-All - WHO SMART Trust v1.7.2

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-XXV-DEV-All**

## Endpoint: GDHCNParticipantDID-XXV-DEV-All

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: test city Trustlist (DID v2) - DEV - All keys did:web:tng-cdn.who.int:v2:trustlist:-:XXV resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XXV/did.json

**managingOrganization**: [Organization test city](Organization-GDHCNParticipant-XXV-DEV.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:XXV



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-XXV-DEV-All",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "test city Trustlist (DID v2) - DEV - All keys\ndid:web:tng-cdn.who.int:v2:trustlist:-:XXV\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XXV/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-XXV-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:XXV"
}

```
