# GDHCNParticipantDID-XXU-DEV-SCA - WHO SMART Trust v1.5.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-XXU-DEV-SCA**

## Endpoint: GDHCNParticipantDID-XXU-DEV-SCA

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: DEV Participant XXU Trustlist (DID v2) - DEV - Certificate Signing Authority did:web:tng-cdn.who.int:v2:trustlist:-:XXU:SCA resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XXU/SCA/did.json

**managingOrganization**: [Organization DEV Participant XXU](Organization-GDHCNParticipant-XXU-DEV.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:XXU:SCA



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-XXU-DEV-SCA",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "DEV Participant XXU Trustlist (DID v2) - DEV - Certificate Signing Authority\ndid:web:tng-cdn.who.int:v2:trustlist:-:XXU:SCA\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XXU/SCA/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-XXU-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:XXU:SCA"
}

```
