# Publish PKI material - JSON Representation - WHO SMART Trust v1.4.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Publish PKI material**

## : Publish PKI material - JSON Representation

| |
| :--- |
| Active as of 2026-02-11 |

[Raw json](Requirements-PublishPKIMaterial.json) | [Download](Requirements-PublishPKIMaterial.json)

