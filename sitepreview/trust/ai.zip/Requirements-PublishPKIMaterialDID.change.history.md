#  - WHO SMART Trust v1.4.0

## : Publish Public Keys as DID - Change History

History of changes for PublishPKIMaterialDID .

