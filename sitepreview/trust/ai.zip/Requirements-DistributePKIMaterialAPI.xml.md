# Distribute PKI material via API - XML Representation - WHO SMART Trust v1.4.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Distribute PKI material via API**

## : Distribute PKI material via API - XML Representation

| |
| :--- |
| Active as of 2026-02-11 |

[Raw xml](Requirements-DistributePKIMaterialAPI.xml) | [Download](Requirements-DistributePKIMaterialAPI.xml)

