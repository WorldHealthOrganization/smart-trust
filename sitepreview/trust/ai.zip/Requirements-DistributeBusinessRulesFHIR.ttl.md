# Distribute FHIR business rules - TTL Representation - WHO SMART Trust v1.4.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Distribute FHIR business rules**

## : Distribute FHIR business rules - TTL Representation

| |
| :--- |
| Active as of 2026-02-11 |

[Raw ttl](Requirements-DistributeBusinessRulesFHIR.ttl) | [Download](Requirements-DistributeBusinessRulesFHIR.ttl)

