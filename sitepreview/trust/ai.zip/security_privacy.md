# Security and Privacy Considerations - WHO SMART Trust v1.4.0

* [**Table of Contents**](toc.md)
* [**Deployment**](deployment.md)
* **Security and Privacy Considerations**

## Security and Privacy Considerations

### Security and Privacy Considerations

