# GDHCNParticipantDID-SUR-DEV-DSC - WHO SMART Trust v1.5.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-SUR-DEV-DSC**

## Endpoint: GDHCNParticipantDID-SUR-DEV-DSC

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: Suriname Trustlist (DID v2) - DEV - Document Signing Certificates did:web:tng-cdn.who.int:v2:trustlist:-:SUR:DSC resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/SUR/DSC/did.json

**managingOrganization**: [Organization Suriname](Organization-GDHCNParticipant-SUR-DEV.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:SUR:DSC



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-SUR-DEV-DSC",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Suriname Trustlist (DID v2) - DEV - Document Signing Certificates\ndid:web:tng-cdn.who.int:v2:trustlist:-:SUR:DSC\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/SUR/DSC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-SUR-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:SUR:DSC"
}

```
