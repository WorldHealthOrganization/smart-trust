# GDHCNParticipantDID-XXJ-DEV-DSC - WHO SMART Trust v1.5.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-XXJ-DEV-DSC**

## Endpoint: GDHCNParticipantDID-XXJ-DEV-DSC

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: DEV Participant XXJ Trustlist (DID v2) - DEV - Document Signing Certificates did:web:tng-cdn.who.int:v2:trustlist:-:XXJ:DSC resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XXJ/DSC/did.json

**managingOrganization**: [Organization DEV Participant XXJ](Organization-GDHCNParticipant-XXJ-DEV.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:XXJ:DSC



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-XXJ-DEV-DSC",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "DEV Participant XXJ Trustlist (DID v2) - DEV - Document Signing Certificates\ndid:web:tng-cdn.who.int:v2:trustlist:-:XXJ:DSC\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XXJ/DSC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-XXJ-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:XXJ:DSC"
}

```
