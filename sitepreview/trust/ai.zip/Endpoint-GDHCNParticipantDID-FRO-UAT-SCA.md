# GDHCNParticipantDID-FRO-UAT-SCA - WHO SMART Trust v1.5.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-FRO-UAT-SCA**

## Endpoint: GDHCNParticipantDID-FRO-UAT-SCA

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: Faroe Islands Trustlist (DID v2) - UAT - Certificate Signing Authority did:web:tng-cdn.who.int:v2:trustlist:-:FRO:SCA resolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/FRO/SCA/did.json

**managingOrganization**: [Organization Faroe Islands](Organization-GDHCNParticipant-FRO-UAT.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:FRO:SCA



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-FRO-UAT-SCA",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Faroe Islands Trustlist (DID v2) - UAT - Certificate Signing Authority\ndid:web:tng-cdn.who.int:v2:trustlist:-:FRO:SCA\nresolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/FRO/SCA/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-FRO-UAT"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:FRO:SCA"
}

```
