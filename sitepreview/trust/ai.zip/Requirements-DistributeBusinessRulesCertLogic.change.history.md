#  - WHO SMART Trust v1.4.0

## : Distribute CertLogic Business Rules - Change History

History of changes for DistributeBusinessRulesCertLogic .

