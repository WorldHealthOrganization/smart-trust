# Receive PKI material - JSON Representation - WHO SMART Trust v1.4.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Receive PKI material**

## : Receive PKI material - JSON Representation

| |
| :--- |
| Active as of 2026-02-11 |

[Raw json](Requirements-ReceivePKUMaterial.json) | [Download](Requirements-ReceivePKUMaterial.json)

