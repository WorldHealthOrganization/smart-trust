# Issue Verifiable Digital Health Certificate - TTL Representation - WHO SMART Trust v1.4.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Issue Verifiable Digital Health Certificate**

## : Issue Verifiable Digital Health Certificate - TTL Representation

| |
| :--- |
| Active as of 2026-02-03 |

[Raw ttl](Requirements-IssuerVDHC.ttl) | [Download](Requirements-IssuerVDHC.ttl)

