# Distribute business rules - JSON Representation - WHO SMART Trust v1.4.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Distribute business rules**

## : Distribute business rules - JSON Representation

| |
| :--- |
| Active as of 2026-02-04 |

[Raw json](Requirements-DistributeBusinessRules.json) | [Download](Requirements-DistributeBusinessRules.json)

