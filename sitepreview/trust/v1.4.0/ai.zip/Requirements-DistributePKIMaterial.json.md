# Distribute PKI material - JSON Representation - WHO SMART Trust v1.4.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Distribute PKI material**

## : Distribute PKI material - JSON Representation

| |
| :--- |
| Active as of 2026-02-11 |

[Raw json](Requirements-DistributePKIMaterial.json) | [Download](Requirements-DistributePKIMaterial.json)

