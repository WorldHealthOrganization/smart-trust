# Retrieve PKI material - WHO SMART Trust v1.4.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Retrieve PKI material**

## Requirements: Retrieve PKI material (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/trust/Requirements/RetrievePKIMaterial | *Version*:1.4.0 |
| Active as of 2026-02-03 | *Computable Name*:Retrieve Public Keys |

 
Retrieve PKI material from a distribution point 

* Publisher: Contact Email
  * [WHO](http://who.int): No contact email has been registered.
* Publisher: Jurisdiction
  * [WHO](http://who.int): 
* Publisher: Statements
  * [WHO](http://who.int): 
* Publisher: Derived from
  * [WHO](http://who.int): This requirement is not derived from another requriement.
* Publisher: Derivatives
  * [WHO](http://who.int): This requirement has the following derivatives:
* Publisher: Participating Actors
  * [WHO](http://who.int): * [Trust Network Participant](ActorDefinition-TrustNetworkParticipant.md)
* [Trust Network Anchor](ActorDefinition-TrustNetworkAnchor.md)


