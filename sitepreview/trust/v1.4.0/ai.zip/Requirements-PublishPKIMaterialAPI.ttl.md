# Publish PKI material via API - TTL Representation - WHO SMART Trust v1.4.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Publish PKI material via API**

## : Publish PKI material via API - TTL Representation

| |
| :--- |
| Active as of 2026-02-03 |

[Raw ttl](Requirements-PublishPKIMaterialAPI.ttl) | [Download](Requirements-PublishPKIMaterialAPI.ttl)

