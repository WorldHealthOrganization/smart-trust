# Publish PKI material as DID - Testing - WHO SMART Trust v1.4.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Publish PKI material as DID**

## Requirements: Publish PKI material as DID - Testing (Experimental) 

| |
| :--- |
| Active as of 2026-02-04 |

### Test Plans

**No test plans are currently available for the Requirements.**

### Test Scripts

**No test scripts are currently available for the Requirements.**

