# Provide Verifiable Digital Health Certificate - WHO SMART Trust v1.4.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Provide Verifiable Digital Health Certificate**

## Requirements: Provide Verifiable Digital Health Certificate (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/trust/Requirements/ProvideVDHC | *Version*:1.4.0 |
| Active as of 2026-02-04 | *Computable Name*:Provide VDHC |

 
Provide a Verifiable Digital Health Certificate to a Receiver 

* Publisher: Contact Email
  * [WHO](http://who.int): No contact email has been registered.
* Publisher: Jurisdiction
  * [WHO](http://who.int): 
* Publisher: Statements
  * [WHO](http://who.int): 
* Publisher: Derived from
  * [WHO](http://who.int): This requirement is not derived from another requriement.
* Publisher: Derivatives
  * [WHO](http://who.int): This requirement has the following derivatives:
* Publisher: Participating Actors
  * [WHO](http://who.int): * [Holder](ActorDefinition-Holder.md)


