# Retrieve PKI material via API - XML Representation - WHO SMART Trust v1.4.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Retrieve PKI material via API**

## : Retrieve PKI material via API - XML Representation

| |
| :--- |
| Active as of 2026-02-03 |

[Raw xml](Requirements-RetrievePKIMaterialAPI.xml) | [Download](Requirements-RetrievePKIMaterialAPI.xml)

