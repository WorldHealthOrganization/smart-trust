# Retrieve PKI material via API - TTL Representation - WHO SMART Trust v1.4.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Retrieve PKI material via API**

## : Retrieve PKI material via API - TTL Representation

| |
| :--- |
| Active as of 2026-02-04 |

[Raw ttl](Requirements-RetrievePKIMaterialAPI.ttl) | [Download](Requirements-RetrievePKIMaterialAPI.ttl)

