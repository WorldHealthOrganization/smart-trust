# Receive Verifiable Digital Health Certificate - TTL Representation - WHO SMART Trust v1.4.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Receive Verifiable Digital Health Certificate**

## : Receive Verifiable Digital Health Certificate - TTL Representation

| |
| :--- |
| Active as of 2026-02-03 |

[Raw ttl](Requirements-ReceiveVDHC.ttl) | [Download](Requirements-ReceiveVDHC.ttl)

