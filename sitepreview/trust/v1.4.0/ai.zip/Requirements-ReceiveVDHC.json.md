# Receive Verifiable Digital Health Certificate - JSON Representation - WHO SMART Trust v1.4.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Receive Verifiable Digital Health Certificate**

## : Receive Verifiable Digital Health Certificate - JSON Representation

| |
| :--- |
| Active as of 2026-02-11 |

[Raw json](Requirements-ReceiveVDHC.json) | [Download](Requirements-ReceiveVDHC.json)

