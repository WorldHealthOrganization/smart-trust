# Publish PKI material as DID - XML Representation - WHO SMART Trust v1.4.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Publish PKI material as DID**

## : Publish PKI material as DID - XML Representation

| |
| :--- |
| Active as of 2026-02-03 |

[Raw xml](Requirements-PublishPKIMaterialDID.xml) | [Download](Requirements-PublishPKIMaterialDID.xml)

