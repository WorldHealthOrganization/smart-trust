# Receive PKI material - XML Representation - WHO SMART Trust v1.4.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Receive PKI material**

## : Receive PKI material - XML Representation

| |
| :--- |
| Active as of 2026-02-03 |

[Raw xml](Requirements-ReceivePKUMaterial.xml) | [Download](Requirements-ReceivePKUMaterial.xml)

