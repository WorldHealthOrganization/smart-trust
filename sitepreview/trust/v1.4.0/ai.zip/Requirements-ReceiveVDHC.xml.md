# Receive Verifiable Digital Health Certificate - XML Representation - WHO SMART Trust v1.4.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Receive Verifiable Digital Health Certificate**

## : Receive Verifiable Digital Health Certificate - XML Representation

| |
| :--- |
| Active as of 2026-02-04 |

[Raw xml](Requirements-ReceiveVDHC.xml) | [Download](Requirements-ReceiveVDHC.xml)

