# Distribute business rules - TTL Representation - WHO SMART Trust v1.4.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Distribute business rules**

## : Distribute business rules - TTL Representation

| |
| :--- |
| Active as of 2026-02-11 |

[Raw ttl](Requirements-DistributeBusinessRules.ttl) | [Download](Requirements-DistributeBusinessRules.ttl)

