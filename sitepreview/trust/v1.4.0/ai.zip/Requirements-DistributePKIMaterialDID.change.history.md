#  - WHO SMART Trust v1.4.0

## : Distribute Public Keys as DID - Change History

History of changes for DistributePKIMaterialDID .

