# Publish Cert Logic business rules - JSON Representation - WHO SMART Trust v1.4.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Publish Cert Logic business rules**

## : Publish Cert Logic business rules - JSON Representation

| |
| :--- |
| Active as of 2026-02-04 |

[Raw json](Requirements-PublishBusinessRulesCertLogic.json) | [Download](Requirements-PublishBusinessRulesCertLogic.json)

