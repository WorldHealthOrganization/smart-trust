# Distribute PKI material as DID - XML Representation - WHO SMART Trust v1.4.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Distribute PKI material as DID**

## : Distribute PKI material as DID - XML Representation

| |
| :--- |
| Active as of 2026-02-03 |

[Raw xml](Requirements-DistributePKIMaterialDID.xml) | [Download](Requirements-DistributePKIMaterialDID.xml)

