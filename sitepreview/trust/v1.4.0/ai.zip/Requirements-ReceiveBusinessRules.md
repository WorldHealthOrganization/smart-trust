# Receive business rules - WHO SMART Trust v1.4.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Receive business rules**

## Requirements: Receive business rules (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/trust/Requirements/ReceiveBusinessRules | *Version*:1.4.0 |
| Active as of 2026-02-04 | *Computable Name*:Receive Business Rules |

 
Receive business rules from a Trust Network Participant, for distribution within the Trust Network 

* Publisher: Contact Email
  * [WHO](http://who.int): No contact email has been registered.
* Publisher: Jurisdiction
  * [WHO](http://who.int): 
* Publisher: Statements
  * [WHO](http://who.int): 
* Publisher: Derived from
  * [WHO](http://who.int): This requirement is not derived from another requriement.
* Publisher: Derivatives
  * [WHO](http://who.int): This requirement has the following derivatives:
* Publisher: Participating Actors
  * [WHO](http://who.int): * [Trust Network Anchor](ActorDefinition-TrustNetworkAnchor.md)


