#  - WHO SMART Trust v1.3.0

## : Publish CertLogic Business Rules - Change History

History of changes for PublishBusinessRulesCertLogic .

