# Publish Cert Logic business rules - XML Representation - WHO SMART Trust v1.3.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Publish Cert Logic business rules**

## : Publish Cert Logic business rules - XML Representation

| |
| :--- |
| Active as of 2025-10-27 |

[Raw xml](Requirements-PublishBusinessRulesCertLogic.xml) | [Download](Requirements-PublishBusinessRulesCertLogic.xml)

