# Publish PKI material as DID - TTL Representation - WHO SMART Trust v1.3.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Publish PKI material as DID**

## : Publish PKI material as DID - TTL Representation

| |
| :--- |
| Active as of 2025-10-27 |

[Raw ttl](Requirements-PublishPKIMaterialDID.ttl) | [Download](Requirements-PublishPKIMaterialDID.ttl)

