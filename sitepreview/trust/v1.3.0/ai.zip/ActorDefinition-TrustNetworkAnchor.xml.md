# Trust Network Anchor - XML Representation - WHO SMART Trust v1.3.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Trust Network Anchor**

## : Trust Network Anchor - XML Representation

| |
| :--- |
| Active as of 2025-10-27 |

[Raw xml](ActorDefinition-TrustNetworkAnchor.xml) | [Download](ActorDefinition-TrustNetworkAnchor.xml)

