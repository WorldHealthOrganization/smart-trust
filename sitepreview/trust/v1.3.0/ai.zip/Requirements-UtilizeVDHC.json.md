# Utilize a Verifiable Digital Health Certificate - JSON Representation - WHO SMART Trust v1.3.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Utilize a Verifiable Digital Health Certificate**

## : Utilize a Verifiable Digital Health Certificate - JSON Representation

| |
| :--- |
| Active as of 2025-10-27 |

[Raw json](Requirements-UtilizeVDHC.json) | [Download](Requirements-UtilizeVDHC.json)

