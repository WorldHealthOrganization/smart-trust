# Receive PKI material as DID - Testing - WHO SMART Trust v1.3.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Receive PKI material as DID**

## Requirements: Receive PKI material as DID - Testing (Experimental) 

| |
| :--- |
| Active as of 2025-10-27 |

### Test Plans

**No test plans are currently available for the Requirements.**

### Test Scripts

**No test scripts are currently available for the Requirements.**

