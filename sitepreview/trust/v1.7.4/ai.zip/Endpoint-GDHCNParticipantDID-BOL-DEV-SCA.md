# GDHCNParticipantDID-BOL-DEV-SCA - WHO SMART Trust v1.7.4

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-BOL-DEV-SCA**

## Endpoint: GDHCNParticipantDID-BOL-DEV-SCA

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: Bolivia (Plurinational State of) Trustlist (DID v2) - DEV - Certificate Signing Authority did:web:tng-cdn.who.int:v2:trustlist:-:BOL:SCA resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/BOL/SCA/did.json

**managingOrganization**: [Organization Bolivia (Plurinational State of)](Organization-GDHCNParticipant-BOL-DEV.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:BOL:SCA



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-BOL-DEV-SCA",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Bolivia (Plurinational State of) Trustlist (DID v2) - DEV - Certificate Signing Authority\ndid:web:tng-cdn.who.int:v2:trustlist:-:BOL:SCA\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/BOL/SCA/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-BOL-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:BOL:SCA"
}

```
