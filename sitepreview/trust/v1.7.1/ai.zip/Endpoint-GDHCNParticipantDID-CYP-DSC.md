# GDHCNParticipantDID-CYP-DSC - WHO SMART Trust v1.7.1

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-CYP-DSC**

## Endpoint: GDHCNParticipantDID-CYP-DSC

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: Cyprus Trustlist (DID v2) - Document Signing Certificates did:web:tng-cdn.who.int:v2:trustlist:-:CYP:DSC resolvable at https://tng-cdn.who.int/v2/trustlist/-/CYP/DSC/did.json

**managingOrganization**: [Organization Cyprus](Organization-GDHCNParticipant-CYP.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:CYP:DSC



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-CYP-DSC",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Cyprus Trustlist (DID v2) - Document Signing Certificates\ndid:web:tng-cdn.who.int:v2:trustlist:-:CYP:DSC\nresolvable at https://tng-cdn.who.int/v2/trustlist/-/CYP/DSC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-CYP"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:CYP:DSC"
}

```
