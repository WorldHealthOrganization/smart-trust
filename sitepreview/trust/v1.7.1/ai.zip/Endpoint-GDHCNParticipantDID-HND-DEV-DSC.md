# GDHCNParticipantDID-HND-DEV-DSC - WHO SMART Trust v1.7.1

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-HND-DEV-DSC**

## Endpoint: GDHCNParticipantDID-HND-DEV-DSC

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: Honduras Trustlist (DID v2) - DEV - Document Signing Certificates did:web:tng-cdn.who.int:v2:trustlist:-:HND:DSC resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/HND/DSC/did.json

**managingOrganization**: [Organization Honduras](Organization-GDHCNParticipant-HND-DEV.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:HND:DSC



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-HND-DEV-DSC",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Honduras Trustlist (DID v2) - DEV - Document Signing Certificates\ndid:web:tng-cdn.who.int:v2:trustlist:-:HND:DSC\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/HND/DSC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-HND-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:HND:DSC"
}

```
