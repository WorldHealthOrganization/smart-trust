# GDHCNParticipantDID-EST-UAT-All - WHO SMART Trust v1.7.1

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-EST-UAT-All**

## Endpoint: GDHCNParticipantDID-EST-UAT-All

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: Estonia Trustlist (DID v2) - UAT - All keys did:web:tng-cdn.who.int:v2:trustlist:-:EST resolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/EST/did.json

**managingOrganization**: [Organization Estonia](Organization-GDHCNParticipant-EST-UAT.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:EST



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-EST-UAT-All",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Estonia Trustlist (DID v2) - UAT - All keys\ndid:web:tng-cdn.who.int:v2:trustlist:-:EST\nresolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/EST/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-EST-UAT"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:EST"
}

```
