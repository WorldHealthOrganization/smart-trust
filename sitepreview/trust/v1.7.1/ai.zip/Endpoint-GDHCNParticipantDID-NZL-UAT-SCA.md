# GDHCNParticipantDID-NZL-UAT-SCA - WHO SMART Trust v1.7.1

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-NZL-UAT-SCA**

## Endpoint: GDHCNParticipantDID-NZL-UAT-SCA

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: New Zealand Trustlist (DID v2) - UAT - Certificate Signing Authority did:web:tng-cdn.who.int:v2:trustlist:-:NZL:SCA resolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/NZL/SCA/did.json

**managingOrganization**: [Organization New Zealand](Organization-GDHCNParticipant-NZL-UAT.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:NZL:SCA



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-NZL-UAT-SCA",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "New Zealand Trustlist (DID v2) - UAT - Certificate Signing Authority\ndid:web:tng-cdn.who.int:v2:trustlist:-:NZL:SCA\nresolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/NZL/SCA/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-NZL-UAT"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:NZL:SCA"
}

```
