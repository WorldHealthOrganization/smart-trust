# GDHCNParticipantDID-MCO-All - WHO SMART Trust v1.7.1

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-MCO-All**

## Endpoint: GDHCNParticipantDID-MCO-All

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: Monaco Trustlist (DID v2) - All keys did:web:tng-cdn.who.int:v2:trustlist:-:MCO resolvable at https://tng-cdn.who.int/v2/trustlist/-/MCO/did.json

**managingOrganization**: [Organization Monaco](Organization-GDHCNParticipant-MCO.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:MCO



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-MCO-All",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Monaco Trustlist (DID v2) - All keys\ndid:web:tng-cdn.who.int:v2:trustlist:-:MCO\nresolvable at https://tng-cdn.who.int/v2/trustlist/-/MCO/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-MCO"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:MCO"
}

```
