# GDHCNParticipantDID-IOM-UAT-DSC - WHO SMART Trust v1.7.1

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-IOM-UAT-DSC**

## Endpoint: GDHCNParticipantDID-IOM-UAT-DSC

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: IOM Trustlist (DID v2) - UAT - Document Signing Certificates did:web:tng-cdn.who.int:v2:trustlist:-:IOM:DSC resolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/IOM/DSC/did.json

**managingOrganization**: [Organization IOM](Organization-GDHCNParticipant-IOM-UAT.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:IOM:DSC



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-IOM-UAT-DSC",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "IOM Trustlist (DID v2) - UAT - Document Signing Certificates\ndid:web:tng-cdn.who.int:v2:trustlist:-:IOM:DSC\nresolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/IOM/DSC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-IOM-UAT"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:IOM:DSC"
}

```
