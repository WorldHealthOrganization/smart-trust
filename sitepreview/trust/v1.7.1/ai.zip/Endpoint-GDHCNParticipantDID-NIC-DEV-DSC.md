# GDHCNParticipantDID-NIC-DEV-DSC - WHO SMART Trust v1.7.1

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-NIC-DEV-DSC**

## Endpoint: GDHCNParticipantDID-NIC-DEV-DSC

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: Nicaragua Trustlist (DID v2) - DEV - Document Signing Certificates did:web:tng-cdn.who.int:v2:trustlist:-:NIC:DSC resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/NIC/DSC/did.json

**managingOrganization**: [Organization Nicaragua](Organization-GDHCNParticipant-NIC-DEV.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:NIC:DSC



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-NIC-DEV-DSC",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Nicaragua Trustlist (DID v2) - DEV - Document Signing Certificates\ndid:web:tng-cdn.who.int:v2:trustlist:-:NIC:DSC\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/NIC/DSC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-NIC-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:NIC:DSC"
}

```
