# GDHCNParticipantDID-BOL-DEV-All - WHO SMART Trust v1.7.1

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-BOL-DEV-All**

## Endpoint: GDHCNParticipantDID-BOL-DEV-All

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: Bolivia (Plurinational State of) Trustlist (DID v2) - DEV - All keys did:web:tng-cdn.who.int:v2:trustlist:-:BOL resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/BOL/did.json

**managingOrganization**: [Organization Bolivia (Plurinational State of)](Organization-GDHCNParticipant-BOL-DEV.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:BOL



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-BOL-DEV-All",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Bolivia (Plurinational State of) Trustlist (DID v2) - DEV - All keys\ndid:web:tng-cdn.who.int:v2:trustlist:-:BOL\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/BOL/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-BOL-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:BOL"
}

```
