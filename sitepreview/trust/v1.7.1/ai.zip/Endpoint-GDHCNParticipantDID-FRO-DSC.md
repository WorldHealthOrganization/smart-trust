# GDHCNParticipantDID-FRO-DSC - WHO SMART Trust v1.7.1

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-FRO-DSC**

## Endpoint: GDHCNParticipantDID-FRO-DSC

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: Faroe Islands Trustlist (DID v2) - Document Signing Certificates did:web:tng-cdn.who.int:v2:trustlist:-:FRO:DSC resolvable at https://tng-cdn.who.int/v2/trustlist/-/FRO/DSC/did.json

**managingOrganization**: [Organization Faroe Islands](Organization-GDHCNParticipant-FRO.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:FRO:DSC



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-FRO-DSC",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Faroe Islands Trustlist (DID v2) - Document Signing Certificates\ndid:web:tng-cdn.who.int:v2:trustlist:-:FRO:DSC\nresolvable at https://tng-cdn.who.int/v2/trustlist/-/FRO/DSC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-FRO"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:FRO:DSC"
}

```
