# GDHCNParticipantDID-URY-DEV-All - WHO SMART Trust v1.7.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-URY-DEV-All**

## Endpoint: GDHCNParticipantDID-URY-DEV-All

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: Uruguay Trustlist (DID v2) - DEV - All keys did:web:tng-cdn.who.int:v2:trustlist:-:URY resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/URY/did.json

**managingOrganization**: [Organization Uruguay](Organization-GDHCNParticipant-URY-DEV.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:URY



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-URY-DEV-All",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Uruguay Trustlist (DID v2) - DEV - All keys\ndid:web:tng-cdn.who.int:v2:trustlist:-:URY\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/URY/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-URY-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:URY"
}

```
