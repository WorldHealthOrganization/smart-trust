# GDHCNParticipantDID-GTM-UAT-DSC - WHO SMART Trust v1.7.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-GTM-UAT-DSC**

## Endpoint: GDHCNParticipantDID-GTM-UAT-DSC

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: Guatemala Trustlist (DID v2) - UAT - Document Signing Certificates did:web:tng-cdn.who.int:v2:trustlist:-:GTM:DSC resolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/GTM/DSC/did.json

**managingOrganization**: [Organization Guatemala](Organization-GDHCNParticipant-GTM-UAT.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:GTM:DSC



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-GTM-UAT-DSC",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Guatemala Trustlist (DID v2) - UAT - Document Signing Certificates\ndid:web:tng-cdn.who.int:v2:trustlist:-:GTM:DSC\nresolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/GTM/DSC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-GTM-UAT"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:GTM:DSC"
}

```
