# GDHCNParticipantDID-PAN-DEV-DSC - WHO SMART Trust v1.7.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-PAN-DEV-DSC**

## Endpoint: GDHCNParticipantDID-PAN-DEV-DSC

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: Panama Trustlist (DID v2) - DEV - Document Signing Certificates did:web:tng-cdn.who.int:v2:trustlist:-:PAN:DSC resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/PAN/DSC/did.json

**managingOrganization**: [Organization Panama](Organization-GDHCNParticipant-PAN-DEV.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:PAN:DSC



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-PAN-DEV-DSC",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Panama Trustlist (DID v2) - DEV - Document Signing Certificates\ndid:web:tng-cdn.who.int:v2:trustlist:-:PAN:DSC\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/PAN/DSC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-PAN-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:PAN:DSC"
}

```
