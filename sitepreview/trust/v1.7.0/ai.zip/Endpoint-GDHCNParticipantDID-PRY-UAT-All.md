# GDHCNParticipantDID-PRY-UAT-All - WHO SMART Trust v1.7.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-PRY-UAT-All**

## Endpoint: GDHCNParticipantDID-PRY-UAT-All

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: Paraguay Trustlist (DID v2) - UAT - All keys did:web:tng-cdn.who.int:v2:trustlist:-:PRY resolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/PRY/did.json

**managingOrganization**: [Organization Paraguay](Organization-GDHCNParticipant-PRY-UAT.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:PRY



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-PRY-UAT-All",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Paraguay Trustlist (DID v2) - UAT - All keys\ndid:web:tng-cdn.who.int:v2:trustlist:-:PRY\nresolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/PRY/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-PRY-UAT"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:PRY"
}

```
