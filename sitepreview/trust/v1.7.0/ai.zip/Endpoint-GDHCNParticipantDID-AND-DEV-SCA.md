# GDHCNParticipantDID-AND-DEV-SCA - WHO SMART Trust v1.7.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-AND-DEV-SCA**

## Endpoint: GDHCNParticipantDID-AND-DEV-SCA

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: Andorra Trustlist (DID v2) - DEV - Certificate Signing Authority did:web:tng-cdn.who.int:v2:trustlist:-:AND:SCA resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/AND/SCA/did.json

**managingOrganization**: [Organization Andorra](Organization-GDHCNParticipant-AND-DEV.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:AND:SCA



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-AND-DEV-SCA",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Andorra Trustlist (DID v2) - DEV - Certificate Signing Authority\ndid:web:tng-cdn.who.int:v2:trustlist:-:AND:SCA\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/AND/SCA/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-AND-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:AND:SCA"
}

```
