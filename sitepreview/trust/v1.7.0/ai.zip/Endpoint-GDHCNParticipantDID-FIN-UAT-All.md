# GDHCNParticipantDID-FIN-UAT-All - WHO SMART Trust v1.7.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-FIN-UAT-All**

## Endpoint: GDHCNParticipantDID-FIN-UAT-All

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: Finland Trustlist (DID v2) - UAT - All keys did:web:tng-cdn.who.int:v2:trustlist:-:FIN resolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/FIN/did.json

**managingOrganization**: [Organization Finland](Organization-GDHCNParticipant-FIN-UAT.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:FIN



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-FIN-UAT-All",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Finland Trustlist (DID v2) - UAT - All keys\ndid:web:tng-cdn.who.int:v2:trustlist:-:FIN\nresolvable at https://tng-cdn-uat.who.int/v2/trustlist/-/FIN/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-FIN-UAT"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:FIN"
}

```
